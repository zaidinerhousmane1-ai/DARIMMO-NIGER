/**
 * DARIMMO - Authentification Firebase Réelle & Gestion des Sessions Multi-Tenant
 * Conforme aux règles d'isolation stricte et de contrôle de rôle côté serveur.
 */

import { 
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  signInWithPopup,
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import { auth as firebaseAuth, googleAuthProvider } from './firebase';
import { firestoreService } from './firestoreService';
import { UserProfile, UserRole } from '../types';

export const DEMO_USERS: Record<string, UserProfile> = {
  owner: {
    id: 'demo_owner_niamey',
    email: 'ousmane.demo@darimmo.ne',
    fullName: 'Ousmane Mamadou (Démo)',
    phone: '+227 90 12 34 56',
    role: 'owner',
    organizationId: 'org_demo_owner',
    organizationName: 'Patrimoine Résidentiel Mamadou (Démo)',
    organizationType: 'individual',
    avatarUrl: '/src/assets/images/darimmo_avatar_landlord_1793803599849.jpg',
    createdAt: '2026-01-10T08:00:00Z'
  },
  agency: {
    id: 'demo_agency_niamey',
    email: 'direction.demo@sahel-immo.ne',
    fullName: 'Amina Dan Koussou (Démo)',
    phone: '+227 90 44 88 12',
    role: 'agency_admin',
    organizationId: 'org_demo_agency',
    organizationName: 'Sahel Immobilier SARL Niamey (Démo)',
    organizationType: 'agency',
    avatarUrl: '/src/assets/images/darimmo_avatar_agency_1793803598996.jpg',
    createdAt: '2025-11-15T09:00:00Z'
  },
  tenant: {
    id: 'demo_tenant_niamey',
    email: 'ibrahim.demo@consult.ne',
    fullName: 'Ibrahim Moussa (Démo)',
    phone: '+227 90 25 44 88',
    role: 'tenant',
    organizationId: 'org_demo_owner',
    organizationName: 'Résidence Sahel & Plateau (Démo)',
    organizationType: 'individual',
    createdAt: '2025-05-20T10:00:00Z'
  },
  super_admin: {
    id: 'demo_admin_niamey',
    email: 'admin.demo@darimmo.ne',
    fullName: 'Moustapha Diallo (Démo Admin)',
    phone: '+227 96 00 00 01',
    role: 'super_admin',
    organizationId: 'org_darimmo_hq_demo',
    organizationName: 'DARIMMO Technologies HQ (Démo)',
    organizationType: 'agency',
    createdAt: '2025-01-01T00:00:00Z'
  }
};

const DEMO_SESSION_KEY = 'darimmo_demo_mode_active_v2';
const DEMO_USER_KEY = 'darimmo_demo_user_selected_v2';

export class AuthService {
  private currentUser: UserProfile | null = null;
  private isDemo: boolean = false;
  private listeners: Array<(user: UserProfile | null, isDemo: boolean) => void> = [];
  private authInitialized: boolean = false;

  constructor() {
    this.initAuth();
  }

  private initAuth(): void {
    // 1. Check if user was in explicit demo mode
    const storedDemo = localStorage.getItem(DEMO_SESSION_KEY);
    const storedDemoUser = localStorage.getItem(DEMO_USER_KEY);

    if (storedDemo === 'true' && storedDemoUser && DEMO_USERS[storedDemoUser]) {
      this.isDemo = true;
      this.currentUser = DEMO_USERS[storedDemoUser];
      this.authInitialized = true;
      this.notify();
      return;
    }

    // 2. Otherwise default state is NOT logged in (waiting for Firebase real credentials)
    // No automatic mock login
    onAuthStateChanged(firebaseAuth, async (fbUser: FirebaseUser | null) => {
      if (this.isDemo) {
        // In demo mode, ignore firebase background auth state
        return;
      }

      if (fbUser) {
        try {
          // Fetch real user profile from Firestore
          let profile = await firestoreService.getUserProfile(fbUser.uid);
          
          if (!profile) {
            // First time Google or newly authenticated user: always created as 'owner'
            const email = fbUser.email || '';
            profile = {
              id: fbUser.uid,
              email: fbUser.email || '',
              fullName: fbUser.displayName || email.split('@')[0] || 'Utilisateur DARIMMO',
              phone: fbUser.phoneNumber || '+227 90 00 00 00',
              role: 'owner',
              organizationId: `org_${fbUser.uid}`,
              organizationName: `Espace ${fbUser.displayName || 'Immobilier'}`,
              organizationType: 'individual',
              avatarUrl: fbUser.photoURL || undefined,
              createdAt: new Date().toISOString()
            };
            await firestoreService.createUserProfile(profile);
          }
          this.currentUser = profile;
        } catch (err) {
          console.warn('Erreur synchronisation profil Firestore:', err);
          this.currentUser = {
            id: fbUser.uid,
            email: fbUser.email || '',
            fullName: fbUser.displayName || fbUser.email?.split('@')[0] || 'Utilisateur',
            phone: '+227 90 00 00 00',
            role: 'owner',
            organizationId: `org_${fbUser.uid}`,
            organizationName: 'Mon Espace Immobilier',
            organizationType: 'individual',
            createdAt: new Date().toISOString()
          };
        }
      } else {
        this.currentUser = null;
      }
      this.authInitialized = true;
      this.notify();
    });
  }

  getCurrentUser(): UserProfile | null {
    return this.currentUser;
  }

  isDemoMode(): boolean {
    return this.isDemo;
  }

  subscribe(listener: (user: UserProfile | null, isDemo: boolean) => void): () => void {
    this.listeners.push(listener);
    listener(this.currentUser, this.isDemo);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify(): void {
    this.listeners.forEach(l => l(this.currentUser, this.isDemo));
  }

  // === AUTHENTIFICATION RÉELLE FIREBASE ===

  async loginWithEmail(email: string, pass: string): Promise<{ success: boolean; error?: string }> {
    if (!email || !email.includes('@')) {
      return { success: false, error: 'Veuillez saisir une adresse e-mail valide.' };
    }
    if (!pass || pass.length < 6) {
      return { success: false, error: 'Le mot de passe doit comporter au moins 6 caractères.' };
    }

    try {
      this.isDemo = false;
      localStorage.removeItem(DEMO_SESSION_KEY);
      localStorage.removeItem(DEMO_USER_KEY);

      const userCredential = await signInWithEmailAndPassword(firebaseAuth, email, pass);
      const fbUser = userCredential.user;

      const profile = await firestoreService.getUserProfile(fbUser.uid);
      if (profile) {
        this.currentUser = profile;
      } else {
        this.currentUser = {
          id: fbUser.uid,
          email: fbUser.email || email,
          fullName: fbUser.displayName || email.split('@')[0],
          phone: '+227 90 00 00 00',
          role: 'owner',
          organizationId: `org_${fbUser.uid}`,
          organizationName: `Gestion Immobilière ${email.split('@')[0]}`,
          organizationType: 'individual',
          createdAt: new Date().toISOString()
        };
        await firestoreService.createUserProfile(this.currentUser);
      }

      this.notify();
      return { success: true };
    } catch (err: any) {
      let message = 'Échec de connexion.';
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        message = 'Identifiants incorrects. Vérifiez votre adresse e-mail et votre mot de passe.';
      } else if (err.code === 'auth/too-many-requests') {
        message = 'Trop de tentatives infructueuses. Veuillez patienter quelques minutes.';
      } else if (err.code === 'auth/network-request-failed') {
        message = 'Erreur réseau. Vérifiez votre connexion internet.';
      } else if (err.message) {
        message = err.message;
      }
      return { success: false, error: message };
    }
  }

  async loginWithGoogle(): Promise<{ success: boolean; error?: string }> {
    try {
      this.isDemo = false;
      localStorage.removeItem(DEMO_SESSION_KEY);
      localStorage.removeItem(DEMO_USER_KEY);

      const userCredential = await signInWithPopup(firebaseAuth, googleAuthProvider);
      const fbUser = userCredential.user;

      let profile = await firestoreService.getUserProfile(fbUser.uid);
      if (!profile) {
        const email = fbUser.email || '';
        profile = {
          id: fbUser.uid,
          email: email,
          fullName: fbUser.displayName || email.split('@')[0] || 'Utilisateur Google',
          phone: fbUser.phoneNumber || '+227 90 00 00 00',
          role: 'owner',
          organizationId: `org_${fbUser.uid}`,
          organizationName: `Espace ${fbUser.displayName || 'Immobilier'}`,
          organizationType: 'individual',
          avatarUrl: fbUser.photoURL || undefined,
          createdAt: new Date().toISOString()
        };
        await firestoreService.createUserProfile(profile);
      }

      this.currentUser = profile;
      this.notify();
      return { success: true };
    } catch (err: any) {
      if (err.code === 'auth/popup-closed-by-user') {
        return { success: false, error: 'Connexion Google annulée par l’utilisateur.' };
      }
      return { success: false, error: err?.message || 'Erreur lors de la connexion Google.' };
    }
  }

  async signup(params: {
    fullName: string;
    email: string;
    phone: string;
    password: string;
    role: 'owner' | 'agency';
    agencyName?: string;
  }): Promise<{ success: boolean; error?: string }> {
    if (!params.fullName.trim() || !params.email.trim() || !params.phone.trim()) {
      return { success: false, error: 'Tous les champs obligatoires doivent être renseignés.' };
    }
    if (!params.password || params.password.length < 6) {
      return { success: false, error: 'Le mot de passe doit comporter au moins 6 caractères.' };
    }

    try {
      this.isDemo = false;
      localStorage.removeItem(DEMO_SESSION_KEY);
      localStorage.removeItem(DEMO_USER_KEY);

      const userCredential = await createUserWithEmailAndPassword(firebaseAuth, params.email, params.password);
      const fbUser = userCredential.user;

      const orgId = `org_${fbUser.uid}`;
      const newUser: UserProfile = {
        id: fbUser.uid,
        email: params.email,
        fullName: params.fullName,
        phone: params.phone,
        role: params.role === 'agency' ? 'agency_admin' : 'owner',
        organizationId: orgId,
        organizationName: params.role === 'agency' ? (params.agencyName || 'Mon Agence Immobilière') : `Gestion ${params.fullName}`,
        organizationType: params.role === 'agency' ? 'agency' : 'individual',
        createdAt: new Date().toISOString()
      };

      // Sauvegarde dans Firestore
      await firestoreService.createUserProfile(newUser);

      this.currentUser = newUser;
      this.notify();
      return { success: true };
    } catch (err: any) {
      let message = 'Erreur lors de la création du compte.';
      if (err.code === 'auth/email-already-in-use') {
        message = 'Cette adresse e-mail est déjà associée à un compte. Veuillez vous connecter.';
      } else if (err.code === 'auth/invalid-email') {
        message = 'Adresse e-mail invalide.';
      } else if (err.code === 'auth/weak-password') {
        message = 'Le mot de passe est trop faible. Minimum 6 caractères.';
      } else if (err.message) {
        message = err.message;
      }
      return { success: false, error: message };
    }
  }

  async sendPasswordReset(email: string): Promise<{ success: boolean; error?: string }> {
    if (!email || !email.includes('@')) {
      return { success: false, error: 'Veuillez saisir votre adresse e-mail.' };
    }

    try {
      await sendPasswordResetEmail(firebaseAuth, email);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Erreur lors de l’envoi du lien de réinitialisation.' };
    }
  }

  // === MODE DÉMO (BAC À SABLE SÉPARÉ SANS FIREBASE) ===

  startDemoMode(roleKey: 'owner' | 'agency' | 'tenant' | 'super_admin' = 'owner'): void {
    this.isDemo = true;
    localStorage.setItem(DEMO_SESSION_KEY, 'true');
    localStorage.setItem(DEMO_USER_KEY, roleKey);
    this.currentUser = DEMO_USERS[roleKey] || DEMO_USERS.owner;
    this.notify();
  }

  switchDemoRole(roleKey: 'owner' | 'agency' | 'tenant' | 'super_admin'): void {
    if (this.isDemo && DEMO_USERS[roleKey]) {
      this.currentUser = DEMO_USERS[roleKey];
      localStorage.setItem(DEMO_USER_KEY, roleKey);
      this.notify();
    }
  }

  exitDemoMode(): void {
    this.isDemo = false;
    localStorage.removeItem(DEMO_SESSION_KEY);
    localStorage.removeItem(DEMO_USER_KEY);
    this.currentUser = null;
    this.notify();
  }

  async logout(): Promise<void> {
    if (this.isDemo) {
      this.exitDemoMode();
    } else {
      try {
        await signOut(firebaseAuth);
      } catch (err) {
        console.warn('Erreur signOut Firebase:', err);
      }
      this.currentUser = null;
      this.notify();
    }
  }
}

export const auth = new AuthService();
