import React, { useState } from 'react';
import { 
  Bug, 
  X, 
  AlertTriangle, 
  WifiOff, 
  Clock, 
  FileWarning, 
  ShieldAlert, 
  FileQuestion, 
  AlertOctagon,
  CheckCircle2
} from 'lucide-react';

interface DevErrorSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerError: (code: 400 | 401 | 403 | 404 | 500, message?: string) => void;
  onSimulateSlowResponse: () => void;
  onSimulateOffline: () => void;
}

export const DevErrorSimulatorModal: React.FC<DevErrorSimulatorModalProps> = ({
  isOpen,
  onClose,
  onTriggerError,
  onSimulateSlowResponse,
  onSimulateOffline
}) => {
  const [activeSimulation, setActiveSimulation] = useState<string | null>(null);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-amber-500/10">
          <div className="flex items-center gap-2">
            <Bug className="w-5 h-5 text-amber-700" />
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Banc d'Essai & Simulation d'Incidents</h3>
              <p className="text-[10px] text-amber-800 font-mono">Réservé exclusivement aux tests et au QA</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/50"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4 text-xs">
          <p className="text-slate-600 leading-relaxed">
            Testez la résilience de DARIMMO en simulant des pannes d'API, des autorisations révoquées ou des coupures de réseau.
          </p>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => {
                onTriggerError(404, 'Le bien ou contrat recherché est introuvable.');
                onClose();
              }}
              className="p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-blue-50 hover:border-blue-300 text-left transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2 mb-1">
                <FileQuestion className="w-4 h-4 text-blue-600" />
                <span className="font-bold text-slate-900 group-hover:text-blue-700">Erreur 404</span>
              </div>
              <p className="text-[11px] text-slate-500">Page ou document introuvable</p>
            </button>

            <button
              type="button"
              onClick={() => {
                onTriggerError(403, 'Accès interdit. Vos privilèges ne vous autorisent pas à modifier les mandats d’agence.');
                onClose();
              }}
              className="p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-amber-50 hover:border-amber-300 text-left transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2 mb-1">
                <ShieldAlert className="w-4 h-4 text-amber-600" />
                <span className="font-bold text-slate-900 group-hover:text-amber-700">Erreur 403</span>
              </div>
              <p className="text-[11px] text-slate-500">Accès non autorisé / RBAC</p>
            </button>

            <button
              type="button"
              onClick={() => {
                onTriggerError(500, 'Échec de synchronisation avec la passerelle bancaire.');
                onClose();
              }}
              className="p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-rose-50 hover:border-rose-300 text-left transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2 mb-1">
                <AlertOctagon className="w-4 h-4 text-rose-600" />
                <span className="font-bold text-slate-900 group-hover:text-rose-700">Erreur 500</span>
              </div>
              <p className="text-[11px] text-slate-500">Erreur interne serveur</p>
            </button>

            <button
              type="button"
              onClick={() => {
                onSimulateOffline();
                onClose();
              }}
              className="p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 hover:border-slate-300 text-left transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2 mb-1">
                <WifiOff className="w-4 h-4 text-slate-600" />
                <span className="font-bold text-slate-900">Perte Réseau</span>
              </div>
              <p className="text-[11px] text-slate-500">Connexion 3G/4G instable</p>
            </button>

            <button
              type="button"
              onClick={() => {
                onSimulateSlowResponse();
                onClose();
              }}
              className="p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-purple-50 hover:border-purple-300 text-left transition-all cursor-pointer group col-span-2"
            >
              <div className="flex items-center gap-2 mb-1">
                <Clock className="w-4 h-4 text-purple-600" />
                <span className="font-bold text-slate-900 group-hover:text-purple-700">Latence Réseau Réaliste (2.5s)</span>
              </div>
              <p className="text-[11px] text-slate-500">Simule les lenteurs de réponse réseau sans bloquer l'interface</p>
            </button>
          </div>
        </div>

        <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-900 text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Fermer le simulateur
          </button>
        </div>
      </div>
    </div>
  );
};
