import React from 'react';
import { AlertOctagon, ShieldAlert, FileQuestion, RefreshCw, Home } from 'lucide-react';

interface ErrorViewProps {
  code: 400 | 401 | 403 | 404 | 500;
  message?: string;
  onGoHome: () => void;
  onRetry?: () => void;
}

export const ErrorView: React.FC<ErrorViewProps> = ({
  code,
  message,
  onGoHome,
  onRetry
}) => {
  const getDetails = () => {
    switch (code) {
      case 403:
        return {
          title: '403 — Accès Non Autorisé',
          desc: message || 'Votre rôle utilisateur actuel ne dispose pas des privilèges nécessaires pour accéder à cet espace ou à ces données d’organisation.',
          icon: ShieldAlert,
          color: 'text-amber-600',
          bg: 'bg-amber-50'
        };
      case 404:
        return {
          title: '404 — Page ou Ressource Introuvable',
          desc: message || 'Le bien immobilier, contrat ou document demandé n’existe pas ou a été déplacé.',
          icon: FileQuestion,
          color: 'text-blue-600',
          bg: 'bg-blue-50'
        };
      case 500:
      default:
        return {
          title: '500 — Erreur Interne du Serveur',
          desc: message || 'Une anomalie technique inattendue s’est produite. Vos données restent intègres et sécurisées.',
          icon: AlertOctagon,
          color: 'text-rose-600',
          bg: 'bg-rose-50'
        };
    }
  };

  const details = getDetails();
  const Icon = details.icon;

  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center p-6 text-center">
      <div className={`w-16 h-16 rounded-2xl ${details.bg} ${details.color} flex items-center justify-center mb-4`}>
        <Icon className="w-8 h-8" />
      </div>
      <h2 className="text-xl font-bold text-slate-900 mb-2">{details.title}</h2>
      <p className="text-xs text-slate-500 max-w-md mb-6 leading-relaxed">
        {details.desc}
      </p>

      <div className="flex items-center gap-3">
        {onRetry && (
          <button
            type="button"
            onClick={onRetry}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Réessayer</span>
          </button>
        )}
        <button
          type="button"
          onClick={onGoHome}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white transition-colors"
        >
          <Home className="w-3.5 h-3.5" />
          <span>Retour à l'accueil</span>
        </button>
      </div>
    </div>
  );
};
