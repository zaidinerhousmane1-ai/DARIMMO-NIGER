import React, { useState, useEffect } from 'react';
import { X, User, Phone, Mail, Building, FileText, DollarSign, AlertCircle } from 'lucide-react';
import { Tenant, Property } from '../../types';

interface TenantModalProps {
  isOpen: boolean;
  tenant: Tenant | null;
  properties: Property[];
  onClose: () => void;
  onSave: (tenant: Tenant) => void;
  organizationId: string;
}

export const TenantModal: React.FC<TenantModalProps> = ({
  isOpen,
  tenant,
  properties,
  onClose,
  onSave,
  organizationId
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('+227 ');
  const [idCardNumber, setIdCardNumber] = useState('');
  const [profession, setProfession] = useState('');
  const [emergencyContact, setEmergencyContact] = useState('');
  const [propertyId, setPropertyId] = useState('');
  const [monthlyRent, setMonthlyRent] = useState(250000);
  const [depositAmount, setDepositAmount] = useState(500000);
  const [status, setStatus] = useState<'actif' | 'ancien'>('actif');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (tenant) {
      setFullName(tenant.fullName);
      setEmail(tenant.email);
      setPhone(tenant.phone);
      setIdCardNumber(tenant.idCardNumber);
      setProfession(tenant.profession);
      setEmergencyContact(tenant.emergencyContact);
      setPropertyId(tenant.propertyId);
      setMonthlyRent(tenant.monthlyRent);
      setDepositAmount(tenant.depositAmount);
      setStatus(tenant.status);
      setNotes(tenant.notes || '');
    } else {
      setFullName('');
      setEmail('');
      setPhone('+227 ');
      setIdCardNumber('');
      setProfession('');
      setEmergencyContact('');
      setPropertyId(properties[0]?.id || '');
      setMonthlyRent(properties[0]?.monthlyRent || 250000);
      setDepositAmount((properties[0]?.monthlyRent || 250000) * 2);
      setStatus('actif');
      setNotes('');
    }
    setError(null);
  }, [tenant, properties, isOpen]);

  if (!isOpen) return null;

  const handlePropertyChange = (newPropId: string) => {
    setPropertyId(newPropId);
    const selectedProp = properties.find(p => p.id === newPropId);
    if (selectedProp) {
      setMonthlyRent(selectedProp.monthlyRent);
      setDepositAmount(selectedProp.monthlyRent * 2);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !phone.trim() || !propertyId) {
      setError('Veuillez renseigner le nom, le téléphone et assigner un bien.');
      return;
    }

    const selectedProp = properties.find(p => p.id === propertyId);

    const savedTenant: Tenant = {
      id: tenant ? tenant.id : `ten_${Date.now()}`,
      organizationId,
      fullName: fullName.trim(),
      email: email.trim(),
      phone: phone.trim(),
      idCardNumber: idCardNumber.trim() || 'Non renseigné',
      profession: profession.trim(),
      emergencyContact: emergencyContact.trim(),
      propertyId,
      propertyTitle: selectedProp ? `${selectedProp.title} (${selectedProp.neighborhood})` : 'Bien non spécifié',
      leaseStartDate: tenant ? tenant.leaseStartDate : new Date().toISOString().split('T')[0],
      entryDate: tenant ? tenant.entryDate : new Date().toISOString().split('T')[0],
      monthlyRent: Number(monthlyRent) || 0,
      depositAmount: Number(depositAmount) || 0,
      status,
      notes: notes.trim(),
      createdAt: tenant ? tenant.createdAt : new Date().toISOString()
    };

    onSave(savedTenant);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-xl w-full overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-emerald-700" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              {tenant ? 'Modifier le Dossier Locataire' : 'Nouveau Dossier Locataire'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/50"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Nom complet du locataire *
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Ex: Ibrahim Moussa"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Numéro de téléphone (+227) *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+227 90 25 44 88"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Adresse e-mail
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ibrahim@exemple.ne"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Profession / Employeur
              </label>
              <input
                type="text"
                value={profession}
                onChange={(e) => setProfession(e.target.value)}
                placeholder="Ex: Ingénieur Télécoms chez Airtel"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                N° CNI ou Passeport
              </label>
              <input
                type="text"
                value={idCardNumber}
                onChange={(e) => setIdCardNumber(e.target.value)}
                placeholder="CNI-NER-2024-XXXX"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Contact d'urgence / Garant
              </label>
              <input
                type="text"
                value={emergencyContact}
                onChange={(e) => setEmergencyContact(e.target.value)}
                placeholder="Nom & Téléphone du garant"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
              />
            </div>
          </div>

          {/* Assigned Property */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Logement / Bien loué *
            </label>
            <select
              required
              value={propertyId}
              onChange={(e) => handlePropertyChange(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
            >
              <option value="">Sélectionnez un bien immobilier...</option>
              {properties.map(p => (
                <option key={p.id} value={p.id}>
                  {p.title} — {p.neighborhood} ({p.monthlyRent.toLocaleString('fr-FR')} FCFA)
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Loyer mensuel (FCFA) *
              </label>
              <input
                type="number"
                step={5000}
                required
                value={monthlyRent}
                onChange={(e) => setMonthlyRent(Number(e.target.value))}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono font-semibold text-emerald-800"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Caution versée (FCFA)
              </label>
              <input
                type="number"
                step={10000}
                value={depositAmount}
                onChange={(e) => setDepositAmount(Number(e.target.value))}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Statut
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as 'actif' | 'ancien')}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
              >
                <option value="actif">Locataire Actif</option>
                <option value="ancien">Ancien Locataire</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Remarques ou clauses particulières
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Conditions spécifiques convenues avec le locataire..."
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors font-medium text-xs cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs transition-colors cursor-pointer"
            >
              {tenant ? 'Enregistrer les modifications' : 'Créer le locataire'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
