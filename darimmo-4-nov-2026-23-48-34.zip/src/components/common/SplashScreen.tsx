import React, { useEffect, useState } from 'react';
import { Sparkles, ShieldCheck } from 'lucide-react';

interface SplashScreenProps {
  onFinished?: () => void;
  minDurationMs?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onFinished,
  minDurationMs = 1200
}) => {
  const [fading, setFading] = useState(false);
  const [progress, setProgress] = useState(15);

  useEffect(() => {
    // Smooth progress simulation
    const p1 = setTimeout(() => setProgress(45), 250);
    const p2 = setTimeout(() => setProgress(78), 650);
    const p3 = setTimeout(() => setProgress(100), 1000);

    // Fade out after min duration
    const fadeTimer = setTimeout(() => {
      setFading(true);
    }, minDurationMs);

    // Call onFinished after fade animation ends
    const endTimer = setTimeout(() => {
      if (onFinished) onFinished();
    }, minDurationMs + 700);

    return () => {
      clearTimeout(p1);
      clearTimeout(p2);
      clearTimeout(p3);
      clearTimeout(fadeTimer);
      clearTimeout(endTimer);
    };
  }, [minDurationMs, onFinished]);

  return (
    <div
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center p-6 bg-gradient-to-b from-slate-950 via-[#032b1e] to-slate-950 text-white overflow-hidden transition-all duration-700 ease-out select-none ${
        fading ? 'opacity-0 scale-102 pointer-events-none' : 'opacity-100 scale-100'
      }`}
      aria-label="Chargement de DARIMMO"
    >
      {/* Ambient background glows */}
      <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-emerald-600/15 blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-emerald-500/10 blur-[120px] pointer-events-none" />

      {/* Main Container */}
      <div className="relative z-10 flex flex-col items-center max-w-sm w-full text-center space-y-7">
        
        {/* Glowing Logo Emblem with Gold & Emerald Accents */}
        <div className="relative group">
          {/* Subtle Outer Glowing Halo */}
          <div className="absolute -inset-2.5 rounded-3xl bg-gradient-to-r from-emerald-500/40 via-amber-400/30 to-emerald-400/40 blur-md opacity-75 animate-pulse" />
          
          <div className="relative w-24 h-24 rounded-2xl bg-gradient-to-br from-emerald-900 via-[#064e3b] to-emerald-950 border-2 border-amber-400/60 shadow-[0_0_50px_rgba(16,185,129,0.35)] flex items-center justify-center">
            {/* Inner stylized "D" logo emblem */}
            <span className="font-extrabold text-5xl tracking-tighter bg-gradient-to-br from-amber-200 via-amber-400 to-yellow-500 bg-clip-text text-transparent drop-shadow-sm font-sans">
              D
            </span>

            {/* Sparkle badge */}
            <div className="absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow-md">
              <Sparkles className="w-3.5 h-3.5 text-slate-950 fill-slate-950" />
            </div>
          </div>
        </div>

        {/* Brand & Slogan */}
        <div className="space-y-2">
          <div className="flex items-center justify-center gap-2">
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-sans">
              DAR<span className="bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-400 bg-clip-text text-transparent">IMMO</span>
            </h1>
          </div>
          
          <p className="text-xs sm:text-sm font-medium text-emerald-100/90 tracking-wide text-balance">
            DARIMMO — La gestion immobilière moderne au Niger
          </p>
        </div>

        {/* Progress Bar & Status Text */}
        <div className="w-full space-y-3 pt-2">
          <div className="w-full bg-slate-900/80 rounded-full h-1.5 p-0.5 border border-emerald-500/20 overflow-hidden shadow-inner backdrop-blur-xs">
            <div
              className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-amber-400 to-emerald-400 shadow-[0_0_12px_rgba(251,191,36,0.5)] transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>

          <p className="text-[11px] font-medium text-emerald-200/70 tracking-wide flex items-center justify-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping inline-block" />
            <span>Initialisation sécurisée de votre espace en cours...</span>
          </p>
        </div>

        {/* Security & Localization Badges */}
        <div className="pt-4 flex items-center justify-center gap-3 text-[10px] text-slate-400 font-medium">
          <span className="flex items-center gap-1 text-emerald-400/80">
            <ShieldCheck className="w-3.5 h-3.5" />
            Chiffrement Sécurisé
          </span>
          <span className="text-slate-600">·</span>
          <span>Cloud Firestore</span>
          <span className="text-slate-600">·</span>
          <span>Niamey 🇳🇪</span>
        </div>

      </div>
    </div>
  );
};
