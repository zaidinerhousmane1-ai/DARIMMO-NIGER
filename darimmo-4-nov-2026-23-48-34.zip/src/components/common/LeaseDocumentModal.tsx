import React from 'react';
import { X, Printer, Download, FileText, CheckCircle2, Building2 } from 'lucide-react';
import { Lease, Property, Tenant } from '../../types';

interface LeaseDocumentModalProps {
  lease: Lease | null;
  property: Property | null;
  tenant: Tenant | null;
  landlordName?: string;
  agencyName?: string;
  onClose: () => void;
}

export const LeaseDocumentModal: React.FC<LeaseDocumentModalProps> = ({
  lease,
  property,
  tenant,
  landlordName = 'Ousmane Mamadou',
  agencyName = 'DARIMMO Gestion Immobilière',
  onClose
}) => {
  if (!lease) return null;

  const handlePrint = () => {
    window.print();
  };

  const monthlyRentFormatted = lease.monthlyRent.toLocaleString('fr-FR');
  const depositFormatted = lease.deposit.toLocaleString('fr-FR');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-3xl w-full overflow-hidden my-8 animate-in fade-in zoom-in-95">
        {/* Controls bar (Hidden during print) */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-700 bg-slate-100 px-2.5 py-1 rounded-md border border-slate-200">
              Modèle Indicatif de Bail
            </span>
            <span className="text-xs text-slate-500 font-mono">{lease.leaseNumber}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-slate-500" />
              Imprimer le Bail / PDF
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              aria-label="Fermer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Legal Disclaimer Banner (Visible on screen and printed) */}
        <div className="bg-amber-50/90 border-b border-amber-200 px-6 py-2.5 text-amber-900 text-xs flex items-center gap-2">
          <span className="font-bold text-amber-700 shrink-0">⚠️ Avertissement légal :</span>
          <span>Modèle indicatif à faire valider par un professionnel du droit avant usage.</span>
        </div>

        {/* Printable Contract Document */}
        <div className="p-8 sm:p-12 font-sans text-slate-800 bg-white space-y-6 text-xs leading-relaxed" id="printable-lease">
          {/* Header */}
          <div className="text-center border-b border-slate-200 pb-6">
            <div className="flex items-center justify-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center font-bold text-base">
                D
              </div>
              <span className="text-xl font-bold tracking-tight text-slate-900">DARIMMO</span>
            </div>
            <h2 className="text-base font-bold text-slate-900 uppercase tracking-wide">
              Contrat de Bail d'Habitation & Professionnel
            </h2>
            <p className="text-[11px] text-slate-500 mt-1">
              Régie immobilière standard · Référence : <strong className="font-mono text-slate-800">{lease.leaseNumber}</strong>
            </p>
          </div>

          {/* Parties */}
          <div className="space-y-3">
            <h3 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] text-emerald-800 border-b border-emerald-100 pb-1">
              Entre les soussignés :
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-100">
              <div>
                <p className="font-semibold text-slate-500 uppercase text-[10px]">Le Bailleur (ou Mandataire)</p>
                <p className="font-bold text-slate-900 text-sm mt-0.5">{landlordName}</p>
                <p className="text-slate-600">{agencyName}</p>
                <p className="text-slate-500">Niamey, République du Niger</p>
              </div>
              <div>
                <p className="font-semibold text-slate-500 uppercase text-[10px]">Le Preneur (Locataire)</p>
                <p className="font-bold text-slate-900 text-sm mt-0.5">{lease.tenantName}</p>
                {tenant && (
                  <>
                    <p className="text-slate-600 font-mono">Tél : {tenant.phone}</p>
                    <p className="text-slate-500">Pièce d'identité : {tenant.idCardNumber}</p>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Article 1: Objet et Désignation */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-slate-900 text-xs">Article 1 — Objet & Désignation des Lieux Loués</h4>
            <p className="text-slate-700">
              Le bailleur donne en location au preneur, qui accepte, le bien immobilier suivant :
            </p>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
              <p><strong>Désignation :</strong> {lease.propertyTitle}</p>
              {property && (
                <p className="text-slate-600 mt-0.5">
                  <strong>Adresse :</strong> {property.address}, Quartier {property.neighborhood}, Niamey ({property.rooms} pièces, surface approx. {property.surface} m²).
                </p>
              )}
            </div>
          </div>

          {/* Article 2: Durée */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-slate-900 text-xs">Article 2 — Durée du Bail</h4>
            <p className="text-slate-700">
              Le présent contrat est consenti et accepté pour une durée déterminée débutant le <strong className="font-mono">{lease.startDate}</strong> et prenant fin le <strong className="font-mono">{lease.endDate}</strong>. Il est renouvelable par tacite reconduction sous réserve de préavis de trois (3) mois formulé par écrit.
            </p>
          </div>

          {/* Article 3: Loyer et Caution */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-slate-900 text-xs">Article 3 — Loyer et Dépôt de Garantie (Caution)</h4>
            <div className="grid grid-cols-2 gap-3 p-3 bg-emerald-50/50 rounded-lg border border-emerald-100">
              <div>
                <span className="text-[10px] text-slate-500 uppercase block font-semibold">Loyer mensuel payable d'avance</span>
                <span className="text-sm font-bold text-emerald-900 font-mono">{monthlyRentFormatted} FCFA</span>
                <span className="text-[10px] text-slate-500 block">Au plus tard le {lease.paymentDueDay} de chaque mois</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase block font-semibold">Dépôt de garantie (Caution)</span>
                <span className="text-sm font-bold text-slate-900 font-mono">{depositFormatted} FCFA</span>
                <span className="text-[10px] text-slate-500 block">Restituable après état des lieux de sortie</span>
              </div>
            </div>
          </div>

          {/* Article 4: Clauses & Obligations */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-900 text-xs">Article 4 — Conditions Générales & Clauses OHADA</h4>
            <ul className="list-disc pl-5 space-y-1 text-slate-700 text-[11px]">
              {lease.clauses.map((clause, idx) => (
                <li key={idx}>{clause}</li>
              ))}
              <li>Les factures d'électricité (Nigelec) et consommations privatives sont à la charge exclusive du preneur.</li>
              <li>Le preneur s'engage à user paisiblement des locaux loués et à ne rien faire qui puisse troubler la tranquillité du voisinage.</li>
            </ul>
          </div>

          {/* Article 5: Juridiction */}
          <div className="space-y-1 text-[11px] text-slate-600">
            <h4 className="font-bold text-slate-900 text-xs">Article 5 — Élection de Domicile & Règlement des Litiges</h4>
            <p>
              Pour l'exécution des présentes, les parties élisent domicile à Niamey. Tout litige relatif à l'interprétation ou à l'exécution du présent contrat sera soumis aux juridictions compétentes du Tribunal de Grande Instance de Niamey.
            </p>
          </div>

          {/* Signatures */}
          <div className="pt-6 border-t border-slate-200 grid grid-cols-2 gap-8 text-center">
            <div>
              <p className="font-bold text-slate-900 mb-1">Le Bailleur (ou Mandataire)</p>
              <p className="text-[10px] text-slate-400 mb-12">« Lu et approuvé, bon pour accord »</p>
              <div className="inline-block p-2 rounded-lg border border-dashed border-slate-300 min-w-[140px]">
                <span className="text-[10px] font-mono text-emerald-700 font-semibold">Cachet & Signature</span>
              </div>
            </div>

            <div>
              <p className="font-bold text-slate-900 mb-1">Le Preneur (Locataire)</p>
              <p className="text-[10px] text-slate-400 mb-12">« Lu et approuvé, bon pour accord »</p>
              <div className="inline-block p-2 rounded-lg border border-dashed border-slate-300 min-w-[140px]">
                <span className="text-[10px] font-mono text-slate-600 font-semibold">Signature du Locataire</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="no-print flex justify-end gap-3 px-6 py-4 bg-slate-50 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
          >
            Fermer
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Télécharger / Imprimer le Contrat de Bail
          </button>
        </div>
      </div>
    </div>
  );
};
