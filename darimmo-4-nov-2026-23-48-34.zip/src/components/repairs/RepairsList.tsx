import React, { useState, useMemo } from 'react';
import { Wrench, Plus, Search, AlertTriangle, CheckCircle2, Clock, Phone, Edit3 } from 'lucide-react';
import { RepairTicket, RepairPriority, RepairStatus } from '../../types';
import { Pagination } from '../common/Pagination';
import { EmptyState } from '../common/EmptyState';

interface RepairsListProps {
  repairs: RepairTicket[];
  onAddRepair: () => void;
  onEditRepair: (repair: RepairTicket) => void;
  onResolveRepair: (repair: RepairTicket) => void;
}

export const RepairsList: React.FC<RepairsListProps> = ({
  repairs,
  onAddRepair,
  onEditRepair,
  onResolveRepair
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const filtered = useMemo(() => {
    return repairs.filter(r => {
      const matchSearch = search.trim() === '' ||
        r.title.toLowerCase().includes(search.toLowerCase()) ||
        r.description.toLowerCase().includes(search.toLowerCase()) ||
        r.propertyTitle.toLowerCase().includes(search.toLowerCase());

      const matchStatus = statusFilter === 'all' || r.status === statusFilter;
      const matchPriority = priorityFilter === 'all' || r.priority === priorityFilter;

      return matchSearch && matchStatus && matchPriority;
    });
  }, [repairs, search, statusFilter, priorityFilter]);

  const paginatedItems = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage, pageSize]);

  const priorityBadge = (p: RepairPriority) => {
    switch (p) {
      case 'urgente':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300">Urgente</span>;
      case 'haute':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-800 border border-amber-200">Haute</span>;
      case 'moyenne':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">Moyenne</span>;
      case 'basse':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-600">Basse</span>;
    }
  };

  const statusBadge = (s: RepairStatus) => {
    switch (s) {
      case 'signale':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">Signalé</span>;
      case 'en_cours':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-50 text-blue-800 border border-blue-200">En cours</span>;
      case 'resolu':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">Résolu</span>;
      case 'annule':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-500">Annulé</span>;
    }
  };

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Pannes & Interventions Techniques</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Suivez les réparations, intervenants et techniciens sur vos logements à Niamey.
          </p>
        </div>

        <button
          type="button"
          onClick={onAddRepair}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Signaler une panne</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-2xs flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
            placeholder="Rechercher par panne, bien, technicien..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-rose-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1); }}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-rose-500"
          >
            <option value="all">Tous les états</option>
            <option value="signale">Signalés</option>
            <option value="en_cours">En cours</option>
            <option value="resolu">Résolus</option>
          </select>

          <select
            value={priorityFilter}
            onChange={(e) => { setPriorityFilter(e.target.value); setCurrentPage(1); }}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-rose-500"
          >
            <option value="all">Toutes priorités</option>
            <option value="urgente">Urgente</option>
            <option value="haute">Haute</option>
            <option value="moyenne">Moyenne</option>
            <option value="basse">Basse</option>
          </select>
        </div>
      </div>

      {/* Content */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={Wrench}
          title="Aucun ticket d'intervention"
          description={
            search || statusFilter !== 'all' || priorityFilter !== 'all'
              ? 'Aucune intervention ne correspond à votre filtre.'
              : 'Aucune panne signalée pour le moment. Tout votre parc est en parfait état de fonctionnement.'
          }
          actionLabel="Créer un ticket"
          onAction={onAddRepair}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {paginatedItems.map(rep => (
            <div
              key={rep.id}
              className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-5 flex flex-col justify-between hover:border-slate-300 transition-all space-y-3"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    {priorityBadge(rep.priority)}
                    {statusBadge(rep.status)}
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {new Date(rep.createdAt).toLocaleDateString('fr-FR')}
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-sm mb-1">{rep.title}</h3>
                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-3">
                  {rep.description}
                </p>

                <div className="p-3 bg-slate-50 rounded-xl space-y-1.5 text-xs text-slate-600">
                  <p className="font-medium text-slate-900 truncate">
                    🏠 {rep.propertyTitle}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Déclaré par : {rep.reportedBy} ({rep.contactPhone})
                  </p>
                  {rep.technicianName && (
                    <p className="text-[11px] text-emerald-800 font-medium">
                      🛠️ Artisan : {rep.technicianName}
                    </p>
                  )}
                  {rep.estimatedCost ? (
                    <p className="text-[11px] font-mono text-slate-700">
                      Coût estimé : {rep.estimatedCost.toLocaleString('fr-FR')} FCFA
                    </p>
                  ) : null}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <button
                  type="button"
                  onClick={() => onEditRepair(rep)}
                  className="inline-flex items-center gap-1 font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Détails & Modifier</span>
                </button>

                {rep.status !== 'resolu' && (
                  <button
                    type="button"
                    onClick={() => onResolveRepair(rep)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 rounded-lg font-semibold transition-colors cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Marquer Résolu</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {filtered.length > 0 && (
        <Pagination
          currentPage={currentPage}
          totalItems={filtered.length}
          pageSize={pageSize}
          onPageChange={setCurrentPage}
          onPageSizeChange={(newSize) => {
            setPageSize(newSize);
            setCurrentPage(1);
          }}
        />
      )}
    </div>
  );
};
