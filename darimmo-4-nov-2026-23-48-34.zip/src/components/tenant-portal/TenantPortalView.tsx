import React, { useState } from 'react';
import { Building2, FileText, Receipt, Wrench, Printer, CheckCircle2, AlertCircle, Phone, Calendar } from 'lucide-react';
import { Property, Tenant, Lease, RentPayment, RepairTicket } from '../../types';

interface TenantPortalViewProps {
  tenant: Tenant;
  property: Property | null;
  lease: Lease | null;
  payments: RentPayment[];
  repairs: RepairTicket[];
  onViewReceipt: (payment: RentPayment) => void;
  onOpenReportRepair: () => void;
}

export const TenantPortalView: React.FC<TenantPortalViewProps> = ({
  tenant,
  property,
  lease,
  payments,
  repairs,
  onViewReceipt,
  onOpenReportRepair
}) => {
  // Tenant's personal payments
  const myPayments = payments.filter(p => p.tenantId === tenant.id);
  const myRepairs = repairs.filter(r => r.propertyId === tenant.propertyId);

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Welcome Header */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-emerald-800 to-slate-900 text-white shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase tracking-wider text-emerald-300 font-semibold">
            Portail Locataire Sécurisé
          </span>
          <h2 className="text-2xl font-bold tracking-tight mt-1">
            Bienvenue, {tenant.fullName}
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            Consultez votre bail, vos quittances officielles et signalez vos demandes d'intervention.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenReportRepair}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-sm transition-colors cursor-pointer shrink-0"
        >
          <Wrench className="w-4 h-4" />
          <span>Signaler un problème technique</span>
        </button>
      </div>

      {/* Lodging & Lease Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Lodging Card */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-5 space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
            <Building2 className="w-5 h-5 text-emerald-700" />
            <h3 className="font-bold text-slate-900 text-sm">Mon Logement Loué</h3>
          </div>

          <div className="space-y-2 text-xs text-slate-600">
            <p className="text-sm font-bold text-slate-900">{tenant.propertyTitle}</p>
            {property && (
              <>
                <p>📍 {property.address}, Quartier {property.neighborhood} ({property.city})</p>
                <div className="flex gap-4 pt-1">
                  <span>📐 {property.surface} m²</span>
                  <span>🚪 {property.rooms} pièces</span>
                  <span>🏢 Type : {property.type}</span>
                </div>
              </>
            )}
            <div className="pt-3 border-t border-slate-100 flex items-baseline justify-between">
              <div>
                <span className="text-[10px] text-slate-400 block">Loyer mensuel contractuel</span>
                <span className="text-lg font-bold text-slate-900 font-mono">
                  {tenant.monthlyRent.toLocaleString('fr-FR')} FCFA
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-400 block">Dépôt de garantie (Caution)</span>
                <span className="text-sm font-semibold text-slate-700 font-mono">
                  {tenant.depositAmount.toLocaleString('fr-FR')} FCFA
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Contract & Lease Details */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-5 space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
            <FileText className="w-5 h-5 text-emerald-700" />
            <h3 className="font-bold text-slate-900 text-sm">Contrat de Bail en Cours</h3>
          </div>

          {lease ? (
            <div className="space-y-3 text-xs text-slate-600">
              <div className="flex justify-between font-medium">
                <span>N° Contrat :</span>
                <span className="font-mono font-bold text-slate-900">{lease.leaseNumber}</span>
              </div>
              <div className="flex justify-between">
                <span>Période de validité :</span>
                <span className="font-mono font-medium text-slate-800">{lease.startDate} → {lease.endDate}</span>
              </div>
              <div className="flex justify-between">
                <span>Jour limite de règlement :</span>
                <span className="font-semibold text-emerald-800">Au plus tard le {lease.paymentDueDay} du mois</span>
              </div>
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100 text-[11px] text-emerald-900">
                <p className="font-semibold mb-1">Clauses contractuelles OHADA appliquées :</p>
                <p>Le loyer est payable par virement bancaire ou Airtel Money. Les quittances sont automatiquement disponibles après encaissement.</p>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400">Aucun contrat officiel rattaché.</p>
          )}
        </div>
      </div>

      {/* Receipts Ledger for the Tenant */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Mes Quittances de Loyer Téléchargeables</h3>
            <p className="text-xs text-slate-500">Téléchargez vos justificatifs officiels avec cachet pour vos démarches</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4 font-semibold">N° Quittance</th>
                <th className="py-3 px-4 font-semibold">Période / Mois</th>
                <th className="py-3 px-4 font-semibold">Montant Réglé</th>
                <th className="py-3 px-4 font-semibold">Mode</th>
                <th className="py-3 px-4 font-semibold">Statut</th>
                <th className="py-3 px-4 font-semibold text-right">Télécharger</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {myPayments.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    Aucun paiement enregistré pour le moment.
                  </td>
                </tr>
              ) : (
                myPayments.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-slate-800">
                      {p.receiptNumber}
                    </td>
                    <td className="py-3 px-4 text-slate-700 font-medium">
                      {p.periodMonth}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {p.amountPaid.toLocaleString('fr-FR')} FCFA
                    </td>
                    <td className="py-3 px-4 uppercase text-[10px] font-semibold text-slate-600">
                      {p.paymentMethod?.replace('_', ' ') || 'Espèces'}
                    </td>
                    <td className="py-3 px-4">
                      {p.status === 'paye' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          Acquitté
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                          En attente
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      {p.status === 'paye' && (
                        <button
                          type="button"
                          onClick={() => onViewReceipt(p)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors cursor-pointer"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>Imprimer Quittance</span>
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Repairs & Maintenance reported by Tenant */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <h3 className="text-sm font-bold text-slate-900">Suivi des Demandes d'Intervention</h3>
          <button
            type="button"
            onClick={onOpenReportRepair}
            className="text-xs font-semibold text-emerald-700 hover:underline cursor-pointer"
          >
            + Nouvelle demande
          </button>
        </div>

        {myRepairs.length === 0 ? (
          <p className="text-xs text-slate-400 py-4 text-center">
            Aucun incident technique en cours sur votre logement.
          </p>
        ) : (
          <div className="space-y-3">
            {myRepairs.map(r => (
              <div key={r.id} className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 flex items-start justify-between gap-3 text-xs">
                <div>
                  <h4 className="font-bold text-slate-900">{r.title}</h4>
                  <p className="text-slate-600 text-[11px] mt-0.5">{r.description}</p>
                  {r.technicianName && (
                    <p className="text-emerald-700 font-medium text-[11px] mt-1">
                      🛠️ Technicien délégué : {r.technicianName}
                    </p>
                  )}
                </div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-semibold shrink-0 ${
                  r.status === 'resolu' ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800'
                }`}>
                  {r.status === 'resolu' ? 'Résolu' : 'En traitement'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
