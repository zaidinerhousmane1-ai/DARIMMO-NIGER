import React from 'react';
import { 
  X, 
  Building2, 
  MapPin, 
  DollarSign, 
  Users, 
  FileText, 
  Wrench, 
  CheckCircle2, 
  ArrowUpRight,
  TrendingDown,
  Phone
} from 'lucide-react';
import { Property, Tenant, Lease, RentPayment, RepairTicket } from '../../types';

interface PropertyDetailModalProps {
  property: Property | null;
  tenants: Tenant[];
  leases: Lease[];
  payments: RentPayment[];
  repairs: RepairTicket[];
  onClose: () => void;
  onEdit: (prop: Property) => void;
  onViewReceipt: (pay: RentPayment) => void;
}

export const PropertyDetailModal: React.FC<PropertyDetailModalProps> = ({
  property,
  tenants,
  leases,
  payments,
  repairs,
  onClose,
  onEdit,
  onViewReceipt
}) => {
  if (!property) return null;

  // Active tenant and lease
  const activeTenant = tenants.find(t => t.propertyId === property.id && t.status === 'actif');
  const activeLease = leases.find(l => l.propertyId === property.id && l.status === 'actif');

  // Property specific payments and repairs
  const propPayments = payments.filter(p => p.propertyId === property.id);
  const propRepairs = repairs.filter(r => r.propertyId === property.id);

  const totalCollected = propPayments.reduce((acc, p) => acc + p.amountPaid, 0);
  const totalRepairsCost = propRepairs.reduce((acc, r) => acc + (r.actualCost || r.estimatedCost || 0), 0);
  const netPerformance = totalCollected - totalRepairsCost;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-3xl w-full overflow-hidden my-6 animate-in fade-in zoom-in-95">
        {/* Header with image */}
        <div className="relative h-48 sm:h-60 bg-slate-900 overflow-hidden">
          <img
            src={property.imageUrl || '/src/assets/images/darimmo_hero_property_1793803599938.jpg'}
            alt={property.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-85"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent" />
          
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-slate-900/70 hover:bg-slate-900 text-white rounded-full transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="absolute bottom-4 left-6 right-6 text-white">
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-600 text-white">
                {property.type}
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white/20 text-white backdrop-blur-xs capitalize">
                {property.status}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">{property.title}</h2>
            <p className="text-xs text-slate-300 flex items-center gap-1 mt-0.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-400" />
              <span>{property.neighborhood}, {property.address} — {property.city}</span>
            </p>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 text-xs overflow-y-auto max-h-[60vh]">
          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">Loyer Mensuel</span>
              <span className="text-base font-bold text-slate-900 font-mono">
                {property.monthlyRent.toLocaleString('fr-FR')} FCFA
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">Charges / mois</span>
              <span className="text-base font-bold text-slate-700 font-mono">
                {(property.charges || 0).toLocaleString('fr-FR')} FCFA
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">Superficie & Pièces</span>
              <span className="text-sm font-bold text-slate-900">
                {property.surface} m² · {property.rooms} pièces
              </span>
            </div>

            <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-100">
              <span className="text-[10px] text-emerald-800 uppercase font-semibold block">Rendement Net Encaissé</span>
              <span className="text-base font-bold text-emerald-900 font-mono">
                {netPerformance.toLocaleString('fr-FR')} FCFA
              </span>
            </div>
          </div>

          {/* Description */}
          {property.description && (
            <div>
              <h4 className="font-bold text-slate-900 mb-1">Description & Commodités</h4>
              <p className="text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                {property.description}
              </p>
            </div>
          )}

          {/* Active Tenant and Lease */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 bg-white">
              <div className="flex items-center gap-2 mb-2 pb-2 border-b border-slate-100">
                <Users className="w-4 h-4 text-emerald-700" />
                <h4 className="font-bold text-slate-900">Locataire Actuel</h4>
              </div>
              {activeTenant ? (
                <div className="space-y-1">
                  <p className="font-semibold text-slate-900 text-sm">{activeTenant.fullName}</p>
                  <p className="text-slate-500">{activeTenant.profession}</p>
                  <a href={`tel:${activeTenant.phone}`} className="inline-flex items-center gap-1 font-mono text-emerald-700 hover:underline pt-1">
                    <Phone className="w-3.5 h-3.5" />
                    <span>{activeTenant.phone}</span>
                  </a>
                </div>
              ) : (
                <p className="text-slate-400">Aucun locataire actif associé.</p>
              )}
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-white">
              <div className="flex items-center gap-2 mb-2 pb-2 border-b border-slate-100">
                <FileText className="w-4 h-4 text-emerald-700" />
                <h4 className="font-bold text-slate-900">Bail Contractuel</h4>
              </div>
              {activeLease ? (
                <div className="space-y-1">
                  <p className="font-bold font-mono text-slate-900">{activeLease.leaseNumber}</p>
                  <p className="text-slate-600">Validité : {activeLease.startDate} → {activeLease.endDate}</p>
                  <p className="text-emerald-800 font-semibold">Caution : {activeLease.deposit.toLocaleString('fr-FR')} FCFA</p>
                </div>
              ) : (
                <p className="text-slate-400">Aucun contrat enregistré.</p>
              )}
            </div>
          </div>

          {/* History of Payments on this Property */}
          <div>
            <h4 className="font-bold text-slate-900 mb-2">Historique des Règlements de Loyer</h4>
            {propPayments.length === 0 ? (
              <p className="text-slate-400 bg-slate-50 p-4 rounded-xl text-center">Aucun paiement sur ce bien.</p>
            ) : (
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-100">
                    <tr>
                      <th className="py-2 px-3">Quittance</th>
                      <th className="py-2 px-3">Mois</th>
                      <th className="py-2 px-3">Montant</th>
                      <th className="py-2 px-3">Statut</th>
                      <th className="py-2 px-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {propPayments.map(p => (
                      <tr key={p.id}>
                        <td className="py-2 px-3 font-mono font-medium text-slate-800">{p.receiptNumber}</td>
                        <td className="py-2 px-3 text-slate-700">{p.periodMonth}</td>
                        <td className="py-2 px-3 font-mono font-bold text-slate-900">{p.amountPaid.toLocaleString('fr-FR')} FCFA</td>
                        <td className="py-2 px-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800">
                            {p.status}
                          </span>
                        </td>
                        <td className="py-2 px-3 text-right">
                          {p.status === 'paye' && (
                            <button
                              type="button"
                              onClick={() => onViewReceipt(p)}
                              className="text-emerald-700 font-semibold hover:underline"
                            >
                              Quittance PDF
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2 px-6 py-4 bg-slate-50 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
          >
            Fermer
          </button>
          <button
            type="button"
            onClick={() => {
              onClose();
              onEdit(property);
            }}
            className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors cursor-pointer"
          >
            Modifier la Fiche
          </button>
        </div>
      </div>
    </div>
  );
};
