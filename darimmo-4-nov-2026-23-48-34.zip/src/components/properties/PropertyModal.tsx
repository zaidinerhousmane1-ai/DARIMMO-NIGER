import React, { useState, useEffect } from 'react';
import { X, Building2, MapPin, DollarSign, Image, AlertCircle } from 'lucide-react';
import { Property, PropertyType, PropertyStatus } from '../../types';

interface PropertyModalProps {
  isOpen: boolean;
  property: Property | null;
  onClose: () => void;
  onSave: (prop: Property) => void;
  organizationId: string;
}

const PROPERTY_TYPES: PropertyType[] = [
  'Maison',
  'Appartement',
  'Chambre',
  'Studio',
  'Boutique',
  'Bureau',
  'Terrain',
  'Immeuble',
  'Autre'
];

const NIAMEY_NEIGHBORHOODS = [
  'Plateau',
  'Koubia',
  'Yantala',
  'Harobanda',
  'Koira Kano',
  'Koira Tégui',
  'Recasement',
  'Francophonie',
  'Terminus',
  'Dares-Salam',
  'Grand Marché',
  'Goudel',
  'Autre quartier'
];

export const PropertyModal: React.FC<PropertyModalProps> = ({
  isOpen,
  property,
  onClose,
  onSave,
  organizationId
}) => {
  const [title, setTitle] = useState('');
  const [type, setType] = useState<PropertyType>('Appartement');
  const [neighborhood, setNeighborhood] = useState('Plateau');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Niamey');
  const [rooms, setRooms] = useState(3);
  const [surface, setSurface] = useState(100);
  const [monthlyRent, setMonthlyRent] = useState(250000);
  const [charges, setCharges] = useState(20000);
  const [status, setStatus] = useState<PropertyStatus>('disponible');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('/src/assets/images/darimmo_hero_property_1793803599938.jpg');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (property) {
      setTitle(property.title);
      setType(property.type);
      setNeighborhood(property.neighborhood);
      setAddress(property.address);
      setCity(property.city || 'Niamey');
      setRooms(property.rooms);
      setSurface(property.surface);
      setMonthlyRent(property.monthlyRent);
      setCharges(property.charges || 0);
      setStatus(property.status);
      setDescription(property.description);
      setImageUrl(property.imageUrl);
    } else {
      setTitle('');
      setType('Appartement');
      setNeighborhood('Plateau');
      setAddress('');
      setCity('Niamey');
      setRooms(3);
      setSurface(90);
      setMonthlyRent(200000);
      setCharges(15000);
      setStatus('disponible');
      setDescription('');
      setImageUrl('/src/assets/images/darimmo_hero_property_1793803599938.jpg');
    }
    setError(null);
  }, [property, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !address.trim()) {
      setError('Veuillez renseigner un titre et une adresse complète.');
      return;
    }

    const savedProperty: Property = {
      id: property ? property.id : `prop_${Date.now()}`,
      organizationId,
      title: title.trim(),
      type,
      neighborhood,
      address: address.trim(),
      city: city.trim() || 'Niamey',
      rooms: Number(rooms) || 1,
      surface: Number(surface) || 0,
      monthlyRent: Number(monthlyRent) || 0,
      charges: Number(charges) || 0,
      status,
      description: description.trim(),
      imageUrl: imageUrl.trim() || '/src/assets/images/darimmo_hero_property_1793803599938.jpg',
      createdAt: property ? property.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onSave(savedProperty);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-xl w-full overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-emerald-700" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              {property ? 'Modifier le Bien Immobilier' : 'Enregistrer un Nouveau Bien'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/50"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Désignation du bien *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Villa Sahel Standing 4 Pièces"
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Type de bien
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as PropertyType)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
              >
                {PROPERTY_TYPES.map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Statut d'occupation
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as PropertyStatus)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
              >
                <option value="disponible">Disponible à la location</option>
                <option value="occupe">Occupé par un locataire</option>
                <option value="maintenance">En travaux / Maintenance</option>
                <option value="en_attente">En attente de bail</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Quartier (Niamey)
              </label>
              <select
                value={neighborhood}
                onChange={(e) => setNeighborhood(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
              >
                {NIAMEY_NEIGHBORHOODS.map(n => (
                  <option key={n} value={n}>{n}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Ville
              </label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Niamey"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Adresse précise / Repère
            </label>
            <input
              type="text"
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Ex: Rue des Ambassades, face Clinique Gamkalley"
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
            />
          </div>

          <div className="grid grid-cols-4 gap-2">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Pièces
              </label>
              <input
                type="number"
                min={1}
                value={rooms}
                onChange={(e) => setRooms(Number(e.target.value))}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Surface (m²)
              </label>
              <input
                type="number"
                min={10}
                value={surface}
                onChange={(e) => setSurface(Number(e.target.value))}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Loyer (FCFA) *
              </label>
              <input
                type="number"
                step={5000}
                min={10000}
                required
                value={monthlyRent}
                onChange={(e) => setMonthlyRent(Number(e.target.value))}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono font-semibold text-emerald-800"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Charges (FCFA)
              </label>
              <input
                type="number"
                step={5000}
                value={charges}
                onChange={(e) => setCharges(Number(e.target.value))}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Description & commodités
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Climatisation, groupe électrogène, forage d'eau, gardiennage..."
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors font-medium text-xs cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs transition-colors cursor-pointer"
            >
              {property ? 'Mettre à jour le bien' : 'Créer le bien'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
