import React, { useState } from 'react';
import { 
  Building2, 
  Check, 
  ShieldCheck, 
  ChevronRight, 
  ArrowRight, 
  Smartphone, 
  FileText, 
  CreditCard, 
  Receipt, 
  Sparkles, 
  HelpCircle, 
  Mail, 
  Phone, 
  MapPin, 
  TrendingUp,
  UserCheck,
  Briefcase
} from 'lucide-react';
import { PlanConfig } from '../../types';

interface LandingPageProps {
  plans: PlanConfig[];
  onOpenLogin: () => void;
  onOpenSignup: () => void;
  onStartTrial: () => void;
  onStartDemo?: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  plans,
  onOpenLogin,
  onOpenSignup,
  onStartTrial,
  onStartDemo
}) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');
  const [activeFaq, setActiveFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: "Comment fonctionne l'essai gratuit de 14 jours ?",
      a: "Dès votre inscription, vous bénéficiez immédiatement de 14 jours d'accès sans engagement à toutes les fonctionnalités avancées de la formule Pro (génération de quittances PDF, alertes de paiement, gestion des dépenses et réparations). Aucune carte bancaire n'est requise."
    },
    {
      q: "Quels sont les moyens de paiement acceptés au Niger ?",
      a: "DARIMMO est spécialement adapté aux réalités locales. Vous pouvez régler votre abonnement via Airtel Money, Nita Transfert d'argent, Amana Express ou par virement bancaire local. La validation administrative s'effectue en quelques minutes."
    },
    {
      q: "Mes données immobilières et locatives sont-elles sécurisées ?",
      a: "Absolument. DARIMMO applique une stricte isolation multi-tenant : vos biens, contrats et finances sont chiffrés et cloisonnés. Vous pouvez exporter une sauvegarde intégrale de vos données en JSON à tout moment."
    },
    {
      q: "Les quittances et baux sont-ils juridiquement valides ?",
      a: "Nos modèles constituent des bases indicatives adaptées aux pratiques immobilières du Niger. Conformément aux bonnes pratiques, nous conseillons de faire valider vos modèles par un professionnel du droit avant usage définitif."
    },
    {
      q: "Puis-je utiliser DARIMMO sur smartphone ou tablette ?",
      a: "Oui, DARIMMO a été conçu 'Mobile-First'. Vous pouvez enregistrer un loyer reçu sur le terrain, photographier un justificatif ou envoyer une quittance directement depuis votre téléphone portable avec une consommation minimale de données 3G/4G."
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* Top Bar Contract (3 zones) */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
          {/* Zone 1: Single text element wordmark */}
          <a href="#" className="flex items-center gap-2.5 text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
            <div className="w-8 h-8 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-bold text-base shadow-sm">
              D
            </div>
            <span>DARIMMO</span>
          </a>

          {/* Zone 2: 4 clean single-line text nav links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
            <a href="#features" className="hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0">Fonctionnalités</a>
            <a href="#proprietaires" className="hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0">Propriétaires</a>
            <a href="#agences" className="hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0">Agences</a>
            <a href="#tarifs" className="hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0">Tarifs</a>
            <a href="#faq" className="hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0">FAQ & Contact</a>
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={onOpenLogin}
              className="text-xs font-semibold text-slate-700 hover:text-emerald-700 px-3 py-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Se connecter
            </button>
            <button
              type="button"
              onClick={onStartTrial}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Essai Gratuit 14 Jours
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section inspired by DoorLoop reference */}
      <section className="relative pt-12 pb-20 md:pt-20 md:pb-28 overflow-hidden bg-gradient-to-b from-white via-emerald-50/20 to-slate-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Proposition de Valeur */}
            <div className="lg:col-span-6 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-50 border border-emerald-200/80 text-emerald-800 text-xs font-medium">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>Le 1er Logiciel SaaS Immobilier Dédié au Niger & à l'Afrique de l'Ouest</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-900 leading-[1.15] text-balance">
                Gérez vos biens, locataires et loyers en toute simplicité.
              </h1>

              <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl">
                Conçu pour les <strong>propriétaires particuliers</strong> et les <strong>agences immobilières</strong>. Suivez vos encaissements, émettez des quittances officielles, pilotez les dépenses et suivez vos paiements Airtel Money, Nita et Amana en temps réel.
              </p>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={onStartTrial}
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl shadow-md hover:shadow-lg transition-all cursor-pointer"
                >
                  <span>Commencer l'essai gratuit de 14 jours</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={onStartDemo || onOpenLogin}
                  className="inline-flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-medium text-amber-900 bg-amber-50 hover:bg-amber-100/90 border border-amber-200 rounded-xl transition-colors cursor-pointer"
                >
                  <span>Essayer en mode démo (Bac à sable)</span>
                </button>
              </div>

              {/* Local Payment Badges / Trust Markers */}
              <div className="pt-4 border-t border-slate-200/60">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  Modes de règlement locaux supportés au Niger :
                </p>
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
                  <span className="px-2.5 py-1 bg-white rounded-md border border-slate-200 font-medium">Nita Transfert</span>
                  <span className="px-2.5 py-1 bg-white rounded-md border border-slate-200 font-medium">Amana Express</span>
                  <span className="px-2.5 py-1 bg-white rounded-md border border-slate-200 font-medium">Airtel Money Niger</span>
                  <span className="px-2.5 py-1 bg-white rounded-md border border-slate-200 font-medium">Virement & Espèces</span>
                </div>
              </div>
            </div>

            {/* Right Column: High Quality Visual Showcase (DoorLoop style app preview) */}
            <div className="lg:col-span-6 relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-slate-200 bg-white">
                <img
                  src="/src/assets/images/darimmo_hero_property_1793803599938.jpg"
                  alt="Résidence moderne à Niamey"
                  referrerPolicy="no-referrer"
                  className="w-full h-64 sm:h-80 object-cover"
                />
                <div className="p-6 bg-white space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">Résidence Sahel — Quartier Plateau</h4>
                      <p className="text-xs text-slate-500">6 Appartements F4 · Niamey, Niger</p>
                    </div>
                    <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-100">
                      Taux d'occupation 100%
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block">Loyers attendus</span>
                      <span className="text-sm font-bold text-slate-900 font-mono">2 100 000 F</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-emerald-50/60 border border-emerald-100">
                      <span className="text-[10px] text-emerald-700 uppercase font-semibold block">Encaissé ce mois</span>
                      <span className="text-sm font-bold text-emerald-800 font-mono">2 100 000 F</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block">Dépenses</span>
                      <span className="text-sm font-bold text-slate-700 font-mono">115 000 F</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Target Audiences: Propriétaires vs Agences */}
      <section className="py-20 bg-white border-y border-slate-200/80">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 mb-3">
              Une solution taillée pour chaque acteur de l'immobilier
            </h2>
            <p className="text-slate-600 text-sm sm:text-base">
              Que vous gériez une villa ou un portefeuille de 200 appartements, DARIMMO s'adapte à votre échelle.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Propriétaires Particuliers */}
            <div id="proprietaires" className="p-8 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-6">
                  <UserCheck className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">Pour les Propriétaires Particuliers</h3>
                <p className="text-sm text-slate-600 mb-6 leading-relaxed">
                  Finis les cahiers manuscrits et les reçus papier perdus. Gardez une vision claire de chaque loyer perçu, des cautions et des échéances de vos locataires à Niamey ou en province.
                </p>
                <ul className="space-y-3 text-xs sm:text-sm text-slate-700 mb-8">
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Émission de quittances PDF téléchargeables et imprimables en 1 clic.</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Suivi des impayés et relances automatiques par SMS/téléphone.</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Archivage numérique des contrats de bail et des pièces d'identité (CNI/Passeport).</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Enregistrement des dépenses d'entretien (plomberie, électricité, gardiennage).</span>
                  </li>
                </ul>
              </div>
              <button
                type="button"
                onClick={onStartTrial}
                className="w-full py-3 px-4 rounded-xl text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 transition-colors text-center cursor-pointer"
              >
                Commencer en tant que Propriétaire
              </button>
            </div>

            {/* Agences Immobilières */}
            <div id="agences" className="p-8 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center mb-6">
                  <Briefcase className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">Pour les Agences & Gestionnaires</h3>
                <p className="text-sm text-slate-600 mb-6 leading-relaxed">
                  Digitalisez vos opérations d'agence. Collaborez avec votre équipe d'agents, affectez des mandats de gestion et générez des redditions de comptes nettes pour chaque bailleur mandant.
                </p>
                <ul className="space-y-3 text-xs sm:text-sm text-slate-700 mb-8">
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>Gestion multi-agents avec droits d'accès personnalisés.</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>Calcul automatisé des honoraires et commissions d'agence (ex: 8% à 10%).</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>Comptabilité mandataire isolée pour chaque propriétaire client.</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>Rapports financiers et journal d'activité d'équipe exportables.</span>
                  </li>
                </ul>
              </div>
              <button
                type="button"
                onClick={onStartTrial}
                className="w-full py-3 px-4 rounded-xl text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 transition-colors text-center cursor-pointer"
              >
                Découvrir l'Espace Agence
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section (Formules d'Abonnement) */}
      <section id="tarifs" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 mb-3">
              Tarifs transparents en Francs CFA (XOF)
            </h2>
            <p className="text-slate-600 text-sm sm:text-base mb-6">
              Choisissez la formule adaptée à votre portefeuille immobilier. Sans engagement de durée.
            </p>

            {/* Monthly / Annual Toggle */}
            <div className="inline-flex items-center p-1 bg-slate-200/80 rounded-xl text-xs font-semibold">
              <button
                type="button"
                onClick={() => setBillingCycle('monthly')}
                className={`px-4 py-2 rounded-lg transition-all cursor-pointer ${
                  billingCycle === 'monthly' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Facturation Mensuelle
              </button>
              <button
                type="button"
                onClick={() => setBillingCycle('annual')}
                className={`px-4 py-2 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                  billingCycle === 'annual' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>Annuel (-15%)</span>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-bold">2 mois offerts</span>
              </button>
            </div>
          </div>

          {/* Plan Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {plans.map(plan => {
              const price = billingCycle === 'annual' ? plan.annualPrice : plan.monthlyPrice;
              const isCustom = plan.id === 'enterprise';

              return (
                <div
                  key={plan.id}
                  className={`rounded-2xl p-6 flex flex-col justify-between transition-all bg-white border ${
                    plan.recommended
                      ? 'border-emerald-600 ring-2 ring-emerald-600/20 shadow-lg relative'
                      : 'border-slate-200/80 shadow-xs hover:border-slate-300'
                  }`}
                >
                  {plan.recommended && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-emerald-700 text-white text-[11px] font-bold uppercase tracking-wider px-3 py-0.5 rounded-full shadow-sm">
                      Recommandé
                    </div>
                  )}

                  <div>
                    <h3 className="text-lg font-bold text-slate-900 mb-1">{plan.name}</h3>
                    <p className="text-xs text-slate-500 mb-4 min-h-[32px]">{plan.tagline}</p>

                    <div className="mb-6 pb-6 border-b border-slate-100">
                      {isCustom ? (
                        <div>
                          <span className="text-2xl font-bold text-slate-900">Sur Devis</span>
                          <span className="text-xs text-slate-400 block mt-1">Accompagnement sur-mesure</span>
                        </div>
                      ) : (
                        <div>
                          <div className="flex items-baseline gap-1">
                            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono">
                              {price.toLocaleString('fr-FR')}
                            </span>
                            <span className="text-xs font-semibold text-slate-500">FCFA</span>
                          </div>
                          <span className="text-[11px] text-slate-400 block mt-0.5">
                            {billingCycle === 'annual' ? 'par an (facturé annuellement)' : 'par mois'}
                          </span>
                        </div>
                      )}
                    </div>

                    <ul className="space-y-2.5 text-xs text-slate-600 mb-8">
                      {plan.features.map((feat, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    type="button"
                    onClick={onStartTrial}
                    className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold transition-colors text-center cursor-pointer ${
                      plan.recommended
                        ? 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-sm'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                    }`}
                  >
                    Choisir {plan.name}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 bg-white border-t border-slate-200/80">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 mb-3">
              Questions Fréquentes
            </h2>
            <p className="text-slate-600 text-sm">
              Tout ce que vous devez savoir pour commencer sereinement avec DARIMMO.
            </p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, idx) => {
              const isOpen = activeFaq === idx;
              return (
                <div
                  key={idx}
                  className="rounded-xl border border-slate-200 overflow-hidden transition-all"
                >
                  <button
                    type="button"
                    onClick={() => setActiveFaq(isOpen ? null : idx)}
                    className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4 font-semibold text-slate-900 text-sm hover:bg-slate-50 transition-colors"
                  >
                    <span>{faq.q}</span>
                    <span className="text-slate-400 text-lg font-mono">{isOpen ? '−' : '+'}</span>
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/50">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact & Support Section in Niamey */}
      <section className="py-16 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8 text-center md:text-left">
            <div className="flex flex-col items-center md:items-start gap-2">
              <div className="w-10 h-10 rounded-xl bg-slate-800 text-emerald-400 flex items-center justify-center">
                <Phone className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-white mt-1">Assistance Téléphonique & WhatsApp</h4>
              <p className="text-xs text-slate-400">+227 90 00 12 34 / +227 96 11 22 33</p>
              <p className="text-[11px] text-slate-500">Du Lundi au Samedi, 8h00 - 18h00</p>
            </div>

            <div className="flex flex-col items-center md:items-start gap-2">
              <div className="w-10 h-10 rounded-xl bg-slate-800 text-emerald-400 flex items-center justify-center">
                <Mail className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-white mt-1">Support E-mail Dédié</h4>
              <p className="text-xs text-slate-400">contact@darimmo.ne / support@darimmo.ne</p>
              <p className="text-[11px] text-slate-500">Réponse garantie sous 2 heures ouvrées</p>
            </div>

            <div className="flex flex-col items-center md:items-start gap-2">
              <div className="w-10 h-10 rounded-xl bg-slate-800 text-emerald-400 flex items-center justify-center">
                <MapPin className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-white mt-1">Siège DARIMMO Niger</h4>
              <p className="text-xs text-slate-400">Quartier Plateau, Avenue de la République</p>
              <p className="text-[11px] text-slate-500">Niamey, République du Niger</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-slate-950 text-slate-400 text-xs border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">DARIMMO</span>
            <span>·</span>
            <span>Logiciel SaaS de Gestion Immobilière</span>
          </div>
          <div className="flex items-center gap-6">
            <a href="#" className="hover:text-white transition-colors">Conditions Générales d'Utilisation</a>
            <a href="#" className="hover:text-white transition-colors">Politique de Confidentialité</a>
            <a href="#" className="hover:text-white transition-colors">Mentions Légales</a>
          </div>
          <div>
            © {new Date().getFullYear()} DARIMMO Technologies SARL. Tous droits réservés.
          </div>
        </div>
      </footer>
    </div>
  );
};
