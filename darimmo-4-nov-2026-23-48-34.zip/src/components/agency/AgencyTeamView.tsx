import React, { useState } from 'react';
import { Briefcase, UserPlus, Users, DollarSign, ShieldCheck, Mail, Phone, Building } from 'lucide-react';
import { AgencyMember, Property } from '../../types';

interface AgencyTeamViewProps {
  members: AgencyMember[];
  properties: Property[];
  onInviteMember: (member: Omit<AgencyMember, 'id' | 'joinedAt'>) => void;
  onUpdateStatus: (id: string, status: 'actif' | 'suspendu') => void;
}

export const AgencyTeamView: React.FC<AgencyTeamViewProps> = ({
  members,
  properties,
  onInviteMember,
  onUpdateStatus
}) => {
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('+227 ');
  const [role, setRole] = useState<'agency_admin' | 'agency_agent'>('agency_agent');
  const [commissionRate, setCommissionRate] = useState(8);

  const handleInviteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !email.trim()) return;

    onInviteMember({
      organizationId: 'org_agency_1',
      fullName: fullName.trim(),
      email: email.trim(),
      phone: phone.trim(),
      role,
      assignedPropertiesCount: 0,
      commissionRate: Number(commissionRate) || 8,
      status: 'actif'
    });

    setFullName('');
    setEmail('');
    setShowInviteModal(false);
  };

  // Agency global stats
  const totalRents = properties.reduce((acc, p) => acc + p.monthlyRent, 0);
  const estimatedAgencyCommission = Math.round(totalRents * 0.1); // 10% average commission

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Espace Cabinet & Agence Immobilière</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Gérez vos gestionnaires de portefeuille, mandats de gestion et commissions d'agence.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowInviteModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4" />
          <span>Inviter un agent</span>
        </button>
      </div>

      {/* Agency KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Membres & Agents Actifs</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <span className="text-2xl font-bold text-slate-900 font-mono">
            {members.filter(m => m.status === 'actif').length} agents
          </span>
          <p className="text-[11px] text-slate-500 mt-1">Équipe opérationnelle à Niamey</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Portefeuille sous Mandat</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <span className="text-2xl font-bold text-slate-900 font-mono">
            {properties.length} biens gérés
          </span>
          <p className="text-[11px] text-slate-500 mt-1">Multi-propriétaires bailleurs</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Commissions d'Agence Estimées</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold text-purple-700 font-mono">
              {estimatedAgencyCommission.toLocaleString('fr-FR')}
            </span>
            <span className="text-xs font-semibold text-slate-500">FCFA/mois</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Sur base taux moyen de 10%</p>
        </div>
      </div>

      {/* Agents Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
        <div className="p-5 border-b border-slate-100">
          <h3 className="text-sm font-bold text-slate-900">Équipe de l'Agence & Rôles</h3>
          <p className="text-xs text-slate-500">Droits d'accès et taux de commission par collaborateur</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4 font-semibold">Agent / Collaborateur</th>
                <th className="py-3 px-4 font-semibold">Rôle</th>
                <th className="py-3 px-4 font-semibold">Contact</th>
                <th className="py-3 px-4 font-semibold">Biens Assignés</th>
                <th className="py-3 px-4 font-semibold">Taux de Commission</th>
                <th className="py-3 px-4 font-semibold">Statut</th>
                <th className="py-3 px-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {members.map(m => (
                <tr key={m.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4">
                    <span className="font-semibold text-slate-900 block">{m.fullName}</span>
                    <span className="text-[10px] text-slate-400 font-mono">Rejoint le {m.joinedAt}</span>
                  </td>
                  <td className="py-3 px-4">
                    {m.role === 'agency_admin' ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-50 text-purple-800 border border-purple-200">
                        Directeur d'Agence
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-50 text-blue-800 border border-blue-200">
                        Agent Gestionnaire
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex flex-col gap-0.5">
                      <span className="font-mono text-slate-800">{m.phone}</span>
                      <span className="text-[10px] text-slate-400">{m.email}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono font-medium text-slate-800">
                    {m.assignedPropertiesCount} biens
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-emerald-800">
                    {m.commissionRate}%
                  </td>
                  <td className="py-3 px-4">
                    {m.status === 'actif' ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                        Actif
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-rose-800 border border-rose-200">
                        Suspendu
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right">
                    {m.role !== 'agency_admin' && (
                      <button
                        type="button"
                        onClick={() => onUpdateStatus(m.id, m.status === 'actif' ? 'suspendu' : 'actif')}
                        className={`text-xs font-semibold hover:underline cursor-pointer ${
                          m.status === 'actif' ? 'text-rose-600' : 'text-emerald-700'
                        }`}
                      >
                        {m.status === 'actif' ? 'Suspendre' : 'Réactiver'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invite Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-md w-full p-6 animate-in fade-in zoom-in-95">
            <h3 className="font-bold text-slate-900 text-sm mb-1">
              Inviter un collaborateur dans l'agence
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              L'agent recevra une invitation avec ses identifiants de connexion.
            </p>

            <form onSubmit={handleInviteSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nom complet</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Ex: Hassane Garba"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-blue-500 text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Adresse e-mail</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="hassane.garba@sahel-immo.ne"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-blue-500 text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Téléphone (+227)</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+227 96 33 22 11"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-blue-500 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Rôle</label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-blue-500 text-xs bg-white"
                  >
                    <option value="agency_agent">Agent Gestionnaire</option>
                    <option value="agency_admin">Directeur / Admin</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Commission (%)</label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={commissionRate}
                    onChange={(e) => setCommissionRate(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-blue-500 text-xs font-mono"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowInviteModal(false)}
                  className="px-3.5 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold transition-colors"
                >
                  Envoyer l'invitation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
