import React, { useState, useMemo } from 'react';
import { FileText, Plus, Search, Calendar, User, Building, Edit3, ShieldAlert, Printer } from 'lucide-react';
import { Lease } from '../../types';
import { Pagination } from '../common/Pagination';
import { EmptyState } from '../common/EmptyState';

interface LeasesListProps {
  leases: Lease[];
  onAddLease: () => void;
  onEditLease: (lease: Lease) => void;
  onViewLeaseDocument: (lease: Lease) => void;
}

export const LeasesList: React.FC<LeasesListProps> = ({
  leases,
  onAddLease,
  onEditLease,
  onViewLeaseDocument
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'actif' | 'expire' | 'resilie'>('all');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const filtered = useMemo(() => {
    return leases.filter(l => {
      const matchSearch = search.trim() === '' ||
        l.leaseNumber.toLowerCase().includes(search.toLowerCase()) ||
        l.tenantName.toLowerCase().includes(search.toLowerCase()) ||
        l.propertyTitle.toLowerCase().includes(search.toLowerCase());

      const matchStatus = statusFilter === 'all' || l.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [leases, search, statusFilter]);

  const paginatedItems = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage, pageSize]);

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Baux & Contrats de Location</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Clauses OHADA, dates d'échéance et inventaire des cautions consignées.
          </p>
        </div>

        <button
          type="button"
          onClick={onAddLease}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Nouveau bail</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-2xs flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
            placeholder="Rechercher par référence de bail, locataire, bien..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value as any); setCurrentPage(1); }}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
          >
            <option value="all">Tous les baux</option>
            <option value="actif">Baux Actifs</option>
            <option value="expire">Baux Expirés</option>
            <option value="resilie">Baux Résiliés</option>
          </select>
        </div>
      </div>

      {/* Content */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="Aucun contrat de location trouvé"
          description={
            search || statusFilter !== 'all'
              ? 'Aucun contrat ne correspond à votre filtre de recherche.'
              : 'Établissez un bail de location écrit et conforme aux règles OHADA pour sécuriser vos revenus.'
          }
          actionLabel="Rédiger un premier bail"
          onAction={onAddLease}
        />
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-100">
                <tr>
                  <th className="py-3 px-4 font-semibold">N° Contrat</th>
                  <th className="py-3 px-4 font-semibold">Locataire</th>
                  <th className="py-3 px-4 font-semibold">Bien Loué</th>
                  <th className="py-3 px-4 font-semibold">Période du Bail</th>
                  <th className="py-3 px-4 font-semibold">Loyer Mensuel</th>
                  <th className="py-3 px-4 font-semibold">Caution Consignée</th>
                  <th className="py-3 px-4 font-semibold">Statut</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paginatedItems.map(l => (
                  <tr key={l.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-slate-800">
                      {l.leaseNumber}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      {l.tenantName}
                    </td>
                    <td className="py-3 px-4 text-slate-600 truncate max-w-xs">
                      {l.propertyTitle}
                    </td>
                    <td className="py-3 px-4 text-slate-600 font-mono">
                      {l.startDate} → {l.endDate}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {l.monthlyRent.toLocaleString('fr-FR')} FCFA
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {l.deposit.toLocaleString('fr-FR')} FCFA
                    </td>
                    <td className="py-3 px-4">
                      {l.status === 'actif' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          Actif
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-600">
                          Terminé
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onViewLeaseDocument(l)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors cursor-pointer"
                          title="Imprimer / Télécharger le bail officiel"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>Bail PDF</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onEditLease(l)}
                          className="p-1 text-slate-500 hover:text-emerald-700 rounded-md hover:bg-slate-100 cursor-pointer"
                          title="Modifier les termes"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <Pagination
            currentPage={currentPage}
            totalItems={filtered.length}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={(newSize) => {
              setPageSize(newSize);
              setCurrentPage(1);
            }}
          />
        </div>
      )}
    </div>
  );
};
