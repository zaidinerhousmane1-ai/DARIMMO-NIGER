/**
 * DARIMMO - Configuration et Initialisation du SDK Firebase
 * Projet: darimmo-niger
 */

import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  setPersistence, 
  browserLocalPersistence 
} from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

export const firebaseConfig = {
  apiKey: "AIzaSyBULvI8TCaIJ-wBkT8QGSd3U4hsEltU4L8",
  authDomain: "darimmo-niger.firebaseapp.com",
  projectId: "darimmo-niger",
  storageBucket: "darimmo-niger.firebasestorage.app",
  messagingSenderId: "375184073986",
  appId: "1:375184073986:web:368133bc898f0302c30e1b",
  measurementId: "G-PPMM8RQ9FW"
};

// Initialisation sécurisée
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app);

// Provider Google
export const googleAuthProvider = new GoogleAuthProvider();
googleAuthProvider.setCustomParameters({
  prompt: 'select_account'
});

// Assure la persistance de session
try {
  setPersistence(auth, browserLocalPersistence).catch(() => {
    // Navigateur en mode privé ou restrictions locales
  });
} catch {
  // Ignorer si non supporté
}
