/**
 * DARIMMO - Types & Data Models
 * SaaS de gestion immobilière pour le Niger et l'Afrique francophone
 */

export type UserRole = 'owner' | 'agency_admin' | 'agency_agent' | 'tenant' | 'super_admin';

export type PlanId = 'essentiel' | 'pro' | 'business' | 'enterprise';

export interface PlanConfig {
  id: PlanId;
  name: string;
  tagline: string;
  monthlyPrice: number; // In FCFA (XOF)
  annualPrice: number;  // In FCFA (discounted)
  maxProperties: number; // -1 for unlimited
  maxTenants: number;    // -1 for unlimited
  maxAgents: number;     // For agencies
  features: string[];
  recommended?: boolean;
}

export interface UserProfile {
  id: string;
  email: string;
  fullName: string;
  phone: string;
  role: UserRole;
  organizationId: string;
  organizationName: string;
  organizationType: 'individual' | 'agency';
  avatarUrl?: string;
  createdAt: string;
  isSuspended?: boolean;
}

export type PropertyType = 
  | 'Maison' 
  | 'Appartement' 
  | 'Chambre' 
  | 'Studio' 
  | 'Boutique' 
  | 'Bureau' 
  | 'Terrain' 
  | 'Immeuble' 
  | 'Autre';

export type PropertyStatus = 'disponible' | 'occupe' | 'maintenance' | 'en_attente';

export interface Property {
  id: string;
  organizationId: string;
  title: string;
  type: PropertyType;
  address: string;
  neighborhood: string; // e.g. Plateau, Koubia, Yantala, Harobanda, Recasement (Niamey)
  city: string; // Defaults to Niamey
  rooms: number;
  surface: number; // In m²
  monthlyRent: number; // In FCFA
  charges?: number; // In FCFA (eau/ordures/gardiennage)
  status: PropertyStatus;
  description: string;
  imageUrl: string;
  assignedAgentId?: string;
  assignedAgentName?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Tenant {
  id: string;
  organizationId: string;
  fullName: string;
  email: string;
  phone: string;
  idCardNumber: string; // CNI / Passeport
  profession: string;
  emergencyContact: string;
  propertyId: string;
  propertyTitle: string;
  leaseStartDate: string;
  entryDate: string;
  monthlyRent: number; // in FCFA
  depositAmount: number; // Caution in FCFA
  status: 'actif' | 'ancien';
  notes?: string;
  createdAt: string;
}

export interface Lease {
  id: string;
  organizationId: string;
  leaseNumber: string; // e.g. CONTRAT-2026-001
  tenantId: string;
  tenantName: string;
  propertyId: string;
  propertyTitle: string;
  startDate: string;
  endDate: string;
  monthlyRent: number; // in FCFA
  deposit: number; // Caution
  paymentDueDay: number; // Day of month (e.g. 5)
  clauses: string[];
  status: 'actif' | 'expire' | 'resilie';
  documentUrl?: string;
  createdAt: string;
}

export type PaymentMethod = 'airtel_money' | 'nita' | 'amana' | 'especes' | 'virement';

export type PaymentStatus = 'paye' | 'en_attente' | 'retard' | 'partiel';

export interface RentPayment {
  id: string;
  organizationId: string;
  receiptNumber: string; // e.g. QUIT-2026-03-004
  tenantId: string;
  tenantName: string;
  propertyId: string;
  propertyTitle: string;
  periodMonth: string; // e.g. "Mars 2026"
  dueDate: string;
  paymentDate?: string;
  amountExpected: number; // in FCFA
  amountPaid: number; // in FCFA
  paymentMethod?: PaymentMethod;
  transactionReference?: string;
  status: PaymentStatus;
  notes?: string;
  createdAt: string;
}

export type ExpenseCategory = 
  | 'Plomberie & Sanitaire' 
  | 'Électricité' 
  | 'Maçonnerie & Peinture' 
  | 'Gardiennage & Sécurité' 
  | 'Nettoyage & Salubrité' 
  | 'Taxes & Impôts Fonciers' 
  | 'Facture Eau / Nigelec' 
  | 'Gestion & Frais Divers';

export interface Expense {
  id: string;
  organizationId: string;
  propertyId?: string;
  propertyTitle?: string;
  category: ExpenseCategory;
  amount: number; // in FCFA
  date: string;
  beneficiary: string;
  description: string;
  receiptUrl?: string;
  receiptRef?: string;
  createdAt: string;
}

export type RepairPriority = 'basse' | 'moyenne' | 'haute' | 'urgente';
export type RepairStatus = 'signale' | 'en_cours' | 'resolu' | 'annule';

export interface RepairTicket {
  id: string;
  organizationId: string;
  propertyId: string;
  propertyTitle: string;
  reportedBy: string; // Tenant name or Landlord
  contactPhone: string;
  title: string;
  description: string;
  priority: RepairPriority;
  status: RepairStatus;
  estimatedCost?: number;
  actualCost?: number;
  technicianName?: string;
  createdAt: string;
  resolvedAt?: string;
}

export interface AgencyMember {
  id: string;
  organizationId: string;
  fullName: string;
  email: string;
  phone: string;
  role: 'agency_admin' | 'agency_agent';
  assignedPropertiesCount: number;
  commissionRate: number; // e.g. 8 for 8%
  status: 'actif' | 'suspendu' | 'invite';
  joinedAt: string;
}

export interface SubscriptionState {
  organizationId: string;
  planId: PlanId;
  status: 'trial' | 'active' | 'expired' | 'suspended';
  trialStartsAt: string;
  trialEndsAt: string;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  billingCycle: 'monthly' | 'annual';
  autoRenew: boolean;
  expiresAt?: string;
  maxProperties?: number;
  maxTenants?: number;
  maxAgents?: number;
}

export type LocalPaymentProvider = 'nita' | 'amana' | 'airtel_money';

export interface SubscriptionPaymentRequest {
  id: string;
  organizationId: string;
  organizationName: string;
  userEmail: string;
  userPhone: string;
  planId: PlanId;
  billingCycle: 'monthly' | 'annual';
  amount: number; // in FCFA
  provider: LocalPaymentProvider;
  transactionReference: string;
  senderName: string;
  senderPhone: string;
  proofDocumentUrl?: string;
  status: 'pending' | 'approved' | 'rejected';
  adminNotes?: string;
  submittedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

export interface AppNotification {
  id: string;
  organizationId: string;
  userId?: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'danger';
  link?: string;
  read: boolean;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  organizationId: string;
  userEmail: string;
  action: string;
  details: string;
  ipAddress?: string;
  timestamp: string;
}

export interface AppConfig {
  maintenanceMode: boolean;
  maintenanceMessage: string;
  maintenanceExpectedEnd?: string;
  paymentInstructions: {
    nita: {
      accountName: string;
      accountNumber: string;
      city: string;
      phone: string;
    };
    amana: {
      accountName: string;
      accountNumber: string;
      city: string;
      phone: string;
    };
    airtelMoney: {
      merchantNumber: string;
      merchantName: string;
      ussdCode: string;
    };
  };
  version: string;
  lastDeployedAt: string;
}
