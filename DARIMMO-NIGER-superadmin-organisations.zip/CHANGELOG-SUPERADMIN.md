# DARIMMO-NIGER — Corrections Super Admin

## Modifications

- Firestore: `super_admin` actif peut lire, créer, modifier et supprimer les documents `properties` de toutes les organisations.
- Les rôles `owner`, `agency_admin` et `agency_agent` restent soumis aux contrôles d'organisation existants.
- Service Firestore : récupération globale des biens et des profils représentant les organisations.
- Console Super Admin : nouvel onglet « Organisations & biens » avec liste des organisations, renommage, suspension/réactivation, liste globale des biens, création par organisation, modification et suppression.
- Le formulaire de bien permet au Super Admin de choisir l'organisation à la création et conserve l'organisation lors d'une modification.
- Enregistrement du bien : la fenêtre attend désormais la réussite de Firestore et reste ouverte si la sauvegarde échoue.
- Suspension : les profils associés à une organisation sont suspendus/réactivés ensemble ; les connexions des comptes suspendus sont refusées.

## Déploiement

1. Faire une sauvegarde du dépôt GitHub actuel.
2. Remplacer les fichiers du dépôt par le contenu de cette archive, en conservant les paramètres du dépôt.
3. Dans Firebase Console > Firestore Database > Rules, remplacer les règles par le contenu de `firestore.rules`, puis publier.
4. Déployer l'application depuis le dépôt mis à jour.
5. Tester avec deux organisations distinctes : le Super Admin doit voir les deux ; un propriétaire de l'organisation A ne doit jamais voir les biens de B.

## Vérifications effectuées

- Les cinq fichiers TypeScript/TSX modifiés passent une transpilation syntaxique TypeScript.
- La compilation complète et les tests Firebase en direct n'ont pas été exécutés dans cet environnement : l'installation des dépendances a dépassé le délai disponible. Il faut donc faire les tests de déploiement avant toute mise en production.

## Architecture des organisations

Les organisations sont actuellement représentées par les profils `users` ayant le rôle `owner` ou `agency_admin`. La console regroupe les profils par `organizationId`. Aucun nouveau schéma de collection `organizations` n'a été introduit.

## Correctif complémentaire — création d'organisations sans compte propriétaire
- Ajout d'une collection Firestore `organizations` administrée exclusivement par le Super Admin.
- Le Super Admin peut créer une fiche d'organisation depuis l'onglet Organisations.
- La liste des organisations fusionne les fiches autonomes et les profils owner/agency_admin existants.
- Les fiches autonomes sont modifiables (nom/suspension) et peuvent recevoir des biens.
- Les nouvelles règles Firestore autorisent uniquement le Super Admin à lire/créer/modifier/supprimer les documents `organizations`.
- La création d'une fiche d'organisation ne crée pas un compte Firebase Authentication ni un compte propriétaire. L'affectation d'un responsable pourra faire l'objet d'une fonctionnalité séparée.
