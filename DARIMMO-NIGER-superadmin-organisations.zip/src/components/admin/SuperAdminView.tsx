import React, { useState } from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Download, 
  Upload, 
  Sliders, 
  Power, 
  RefreshCw, 
  Search, 
  FileText,
  DollarSign,
  Users,
  Building
} from 'lucide-react';
import { 
  SubscriptionPaymentRequest, 
  PlanConfig, 
  AppConfig, 
  AuditLog, 
  Property,
  UserProfile
} from '../../types';

interface SuperAdminViewProps {
  paymentRequests: SubscriptionPaymentRequest[];
  plans: PlanConfig[];
  config: AppConfig;
  auditLogs: AuditLog[];
  properties: Property[];
  organizations: UserProfile[];
  onCreatePropertyForOrganization: (organizationId: string) => void;
  onCreateOrganization: (organizationName: string, organizationType: 'individual' | 'agency') => Promise<void> | void;
  onEditGlobalProperty: (property: Property) => void;
  onDeleteGlobalProperty: (propertyId: string) => void;
  onRenameOrganization: (organizationId: string, organizationName: string) => Promise<void> | void;
  onToggleOrganizationSuspension: (organizationId: string, suspended: boolean) => Promise<void> | void;
  onReviewPayment: (requestId: string, status: 'approved' | 'rejected', notes: string) => void;
  onUpdatePlans: (plans: PlanConfig[]) => void;
  onUpdateConfig: (config: AppConfig) => void;
  onExportBackup: () => void;
  onImportBackup: (jsonContent: string) => void;
  onResetFactory: () => void;
}

export const SuperAdminView: React.FC<SuperAdminViewProps> = ({
  paymentRequests,
  plans,
  config,
  auditLogs,
  properties,
  organizations,
  onCreatePropertyForOrganization,
  onCreateOrganization,
  onEditGlobalProperty,
  onDeleteGlobalProperty,
  onRenameOrganization,
  onToggleOrganizationSuspension,
  onReviewPayment,
  onUpdatePlans,
  onUpdateConfig,
  onExportBackup,
  onImportBackup,
  onResetFactory
}) => {
  const [activeTab, setActiveTab] = useState<'payments' | 'plans' | 'maintenance' | 'backup' | 'logs' | 'organizations'>('payments');
  const [selectedReq, setSelectedReq] = useState<SubscriptionPaymentRequest | null>(null);
  const [adminNote, setAdminNote] = useState('');
  const [search, setSearch] = useState('');
  const [organizationNameDrafts, setOrganizationNameDrafts] = useState<Record<string, string>>({});
  const [savingOrganizationId, setSavingOrganizationId] = useState<string | null>(null);
  const [newOrganizationName, setNewOrganizationName] = useState('');
  const [newOrganizationType, setNewOrganizationType] = useState<'individual' | 'agency'>('agency');
  const [creatingOrganization, setCreatingOrganization] = useState(false);

  // Maintenance form state
  const [maintActive, setMaintActive] = useState(config.maintenanceMode);
  const [maintMsg, setMaintMsg] = useState(config.maintenanceMessage);
  const [maintEnd, setMaintEnd] = useState(config.maintenanceExpectedEnd || '');

  // Keep in sync with incoming config updates (including Firestore real-time snapshots)
  React.useEffect(() => {
    setMaintActive(config.maintenanceMode);
    setMaintMsg(config.maintenanceMessage);
    setMaintEnd(config.maintenanceExpectedEnd || '');
  }, [config.maintenanceMode, config.maintenanceMessage, config.maintenanceExpectedEnd]);

  // Plans editor state
  const [editablePlans, setEditablePlans] = useState<PlanConfig[]>(plans);

  const handleQuickToggleMaintenance = () => {
    const nextState = !config.maintenanceMode;
    setMaintActive(nextState);
    onUpdateConfig({
      ...config,
      maintenanceMode: nextState,
      maintenanceMessage: maintMsg,
      maintenanceExpectedEnd: maintEnd
    });
  };

  const handleSaveMaintenance = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateConfig({
      ...config,
      maintenanceMode: maintActive,
      maintenanceMessage: maintMsg,
      maintenanceExpectedEnd: maintEnd
    });
  };

  const handlePlanPriceChange = (index: number, field: 'monthlyPrice' | 'annualPrice' | 'maxProperties', val: number) => {
    const updated = [...editablePlans];
    updated[index] = { ...updated[index], [field]: val };
    setEditablePlans(updated);
  };

  const handleSavePlans = () => {
    onUpdatePlans(editablePlans);
  };

  const pendingRequests = paymentRequests.filter(r => r.status === 'pending');

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-slate-900 text-white shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-tight">Console Centrale Super Admin</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Pilotage des paiements locaux au Niger, tarification, sauvegarde persistante et maintenance.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <div className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700">
            <span className="text-slate-400">Paiements en attente : </span>
            <strong className="text-amber-400 font-mono">{pendingRequests.length}</strong>
          </div>
        </div>
      </div>

      {/* Panneau de Contrôle Bien en Vue : État du Système & Maintenance */}
      <div className={`p-6 rounded-2xl border transition-all ${
        config.maintenanceMode
          ? 'bg-gradient-to-r from-rose-950/90 via-slate-900 to-rose-950/80 border-rose-500/50 text-white shadow-lg'
          : 'bg-white border-slate-200/90 text-slate-900 shadow-2xs'
      }`}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
          <div className="flex items-start gap-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 border ${
              config.maintenanceMode
                ? 'bg-rose-500/20 text-rose-400 border-rose-500/40 shadow-inner'
                : 'bg-emerald-50 text-emerald-700 border-emerald-200'
            }`}>
              <Power className={`w-6 h-6 ${config.maintenanceMode ? 'animate-pulse' : ''}`} />
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base font-bold tracking-tight">
                  État du Système & Maintenance
                </h3>
                <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider inline-flex items-center gap-1.5 ${
                  config.maintenanceMode
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                }`}>
                  <span className={`w-2 h-2 rounded-full ${config.maintenanceMode ? 'bg-rose-400 animate-ping' : 'bg-emerald-500'}`} />
                  <span>{config.maintenanceMode ? 'Mode Maintenance ACTIF' : 'Système Opérationnel'}</span>
                </span>
              </div>

              <p className={`text-xs max-w-2xl leading-relaxed ${config.maintenanceMode ? 'text-slate-300' : 'text-slate-500'}`}>
                {config.maintenanceMode
                  ? "ATTENTION : Le mode maintenance est actuellement activé. Tous les visiteurs et utilisateurs ordinaires voient immédiatement l'écran de maintenance avec bouton WhatsApp d'urgence. En tant que Super Admin, vous gardez l'accès complet et pouvez le désactiver à tout moment."
                  : "Le service DARIMMO fonctionne normalement au Niger. Activez le mode maintenance en 1 clic pour verrouiller temporairement l'accès public lors des opérations de mise à niveau."}
              </p>
            </div>
          </div>

          {/* Big 1-click Toggle Switch */}
          <div className="flex items-center gap-4 self-end md:self-center shrink-0">
            <div className="text-right hidden sm:block">
              <span className="text-[11px] font-semibold text-slate-400 block uppercase tracking-wider">
                Bascule en 1 clic
              </span>
              <span className={`text-xs font-bold ${config.maintenanceMode ? 'text-rose-400' : 'text-emerald-700'}`}>
                {config.maintenanceMode ? 'Désactiver' : 'Activer'}
              </span>
            </div>

            <button
              type="button"
              onClick={handleQuickToggleMaintenance}
              className={`relative inline-flex h-9 w-16 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden focus:ring-2 focus:ring-indigo-500 shadow-sm ${
                config.maintenanceMode ? 'bg-rose-600' : 'bg-slate-300 hover:bg-slate-400'
              }`}
              role="switch"
              aria-checked={config.maintenanceMode}
              title={config.maintenanceMode ? "Cliquez pour désactiver le mode maintenance" : "Cliquez pour activer le mode maintenance"}
            >
              <span
                aria-hidden="true"
                className={`pointer-events-none inline-block h-8 w-8 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out flex items-center justify-center ${
                  config.maintenanceMode ? 'translate-x-7' : 'translate-x-0'
                }`}
              >
                <Power className={`w-4 h-4 ${config.maintenanceMode ? 'text-rose-600 font-bold' : 'text-slate-400'}`} />
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('payments')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'payments' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>Paiements Nita / Amana / Airtel</span>
          {pendingRequests.length > 0 && (
            <span className="w-5 h-5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-bold flex items-center justify-center">
              {pendingRequests.length}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('plans')}
          className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'plans' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Gestion des Tarifs & Limites
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('maintenance')}
          className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'maintenance' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Mode Maintenance Système
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('backup')}
          className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'backup' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Sauvegardes & Restauration
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('logs')}
          className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'logs' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Journaux d'Audit
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('organizations')}
          className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'organizations' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Organisations & biens
        </button>
      </div>

      {/* Tab 1: Payment Verification Dashboard */}
      {activeTab === 'payments' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Demandes de Paiement à Vérifier</h3>
              <p className="text-xs text-slate-500">Validez les bordereaux et activez les accès sans attendre</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-100">
                <tr>
                  <th className="py-3 px-4 font-semibold">Date de soumission</th>
                  <th className="py-3 px-4 font-semibold">Organisation / Demandeur</th>
                  <th className="py-3 px-4 font-semibold">Opérateur (Niger)</th>
                  <th className="py-3 px-4 font-semibold">Formule</th>
                  <th className="py-3 px-4 font-semibold">Montant (FCFA)</th>
                  <th className="py-3 px-4 font-semibold">Réf. Transaction</th>
                  <th className="py-3 px-4 font-semibold">Statut</th>
                  <th className="py-3 px-4 font-semibold text-right">Décision Admin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paymentRequests.map(req => (
                  <tr key={req.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {new Date(req.submittedAt).toLocaleDateString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-semibold text-slate-900 block">{req.organizationName}</span>
                      <span className="text-[10px] text-slate-400">{req.senderName} ({req.senderPhone})</span>
                    </td>
                    <td className="py-3 px-4 font-semibold uppercase text-slate-700">
                      {req.provider.replace('_', ' ')}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900 uppercase">
                      {req.planId} ({req.billingCycle})
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-emerald-800">
                      {req.amount.toLocaleString('fr-FR')}
                    </td>
                    <td className="py-3 px-4 font-mono font-medium text-slate-900">
                      {req.transactionReference}
                    </td>
                    <td className="py-3 px-4">
                      {req.status === 'approved' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          Approuvé
                        </span>
                      ) : req.status === 'pending' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                          En attente
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-rose-800 border border-rose-200">
                          Rejeté
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      {req.status === 'pending' ? (
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedReq(req);
                              setAdminNote('Vérifié sur le compte marchand');
                            }}
                            className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 transition-colors cursor-pointer"
                          >
                            Examiner
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-400">Traité</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Review Modal */}
      {selectedReq && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-md w-full p-6 animate-in fade-in zoom-in-95 text-xs">
            <h3 className="font-bold text-slate-900 text-sm mb-2">
              Vérification du Paiement {selectedReq.provider.toUpperCase()}
            </h3>
            
            <div className="p-3 bg-slate-50 rounded-xl space-y-1 mb-4 border border-slate-200/80">
              <p><strong className="text-slate-700">Client :</strong> {selectedReq.organizationName}</p>
              <p><strong className="text-slate-700">Expéditeur déclaré :</strong> {selectedReq.senderName} ({selectedReq.senderPhone})</p>
              <p><strong className="text-slate-700">Réf. transaction :</strong> <span className="font-mono font-bold text-slate-900">{selectedReq.transactionReference}</span></p>
              <p><strong className="text-slate-700">Montant attendu :</strong> <span className="font-mono font-bold text-emerald-800">{selectedReq.amount.toLocaleString('fr-FR')} FCFA</span></p>
              <p><strong className="text-slate-700">Formule demandée :</strong> {selectedReq.planId.toUpperCase()} ({selectedReq.billingCycle})</p>
            </div>

            <div className="space-y-2 mb-4">
              <label className="block font-semibold text-slate-700">
                Commentaire d'audit interne
              </label>
              <input
                type="text"
                value={adminNote}
                onChange={(e) => setAdminNote(e.target.value)}
                placeholder="Ex: Rapprochement effectué sur relevé bancaire / SMS Airtel..."
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setSelectedReq(null)}
                className="px-3.5 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
              >
                Fermer
              </button>
              <button
                type="button"
                onClick={() => {
                  onReviewPayment(selectedReq.id, 'rejected', adminNote || 'Référence introuvable');
                  setSelectedReq(null);
                }}
                className="flex-1 py-2 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 font-semibold transition-colors"
              >
                Rejeter le paiement
              </button>
              <button
                type="button"
                onClick={() => {
                  onReviewPayment(selectedReq.id, 'approved', adminNote || 'Paiement confirmé');
                  setSelectedReq(null);
                }}
                className="flex-1 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold transition-colors"
              >
                Valider & Activer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Pricing & Limits Editor */}
      {activeTab === 'plans' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-6 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Configuration Commerciale des Formules</h3>
              <p className="text-xs text-slate-500">Modifiez les tarifs et les plafonds de biens en temps réel sans retoucher au code source.</p>
            </div>
            <button
              type="button"
              onClick={handleSavePlans}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              Sauvegarder les Tarifs
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {editablePlans.filter(p => p.id !== 'enterprise').map((plan, idx) => (
              <div key={plan.id} className="p-4 rounded-xl border border-slate-200 space-y-3 bg-slate-50/50 text-xs">
                <h4 className="font-bold text-slate-900 text-sm">{plan.name}</h4>
                
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Prix mensuel (FCFA)
                  </label>
                  <input
                    type="number"
                    step={500}
                    value={plan.monthlyPrice}
                    onChange={(e) => handlePlanPriceChange(idx, 'monthlyPrice', Number(e.target.value))}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-white font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Prix annuel avec remise (FCFA)
                  </label>
                  <input
                    type="number"
                    step={1000}
                    value={plan.annualPrice}
                    onChange={(e) => handlePlanPriceChange(idx, 'annualPrice', Number(e.target.value))}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-white font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Limite max de biens (-1 pour illimité)
                  </label>
                  <input
                    type="number"
                    value={plan.maxProperties}
                    onChange={(e) => handlePlanPriceChange(idx, 'maxProperties', Number(e.target.value))}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-white font-mono"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Maintenance Mode */}
      {activeTab === 'maintenance' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-6 max-w-2xl">
          <h3 className="text-sm font-bold text-slate-900 mb-1">Contrôle du Mode Maintenance</h3>
          <p className="text-xs text-slate-500 mb-6">
            Lorsqu'il est activé, les utilisateurs standards sont redirigés vers une page d'attente soignée pendant les opérations sensibles.
          </p>

          <form onSubmit={handleSaveMaintenance} className="space-y-4 text-xs">
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 block text-sm">Activer le Mode Maintenance</span>
                <span className="text-slate-500 text-xs">Bloque l'accès aux utilisateurs ordinaires</span>
              </div>
              <input
                type="checkbox"
                checked={maintActive}
                onChange={(e) => setMaintActive(e.target.checked)}
                className="w-5 h-5 rounded text-rose-600 focus:ring-rose-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Message affiché aux utilisateurs
              </label>
              <textarea
                rows={3}
                value={maintMsg}
                onChange={(e) => setMaintMsg(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Date & Heure prévisionnelle de fin
              </label>
              <input
                type="text"
                value={maintEnd}
                onChange={(e) => setMaintEnd(e.target.value)}
                placeholder="Ex: 2026-11-04 18:00 (Heure de Niamey)"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 text-xs"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold transition-colors cursor-pointer"
            >
              Appliquer la configuration de maintenance
            </button>
          </form>
        </div>
      )}

      {/* Tab 4: Backup & Restore */}
      {activeTab === 'backup' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-6 space-y-6 max-w-2xl">
          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">Sauvegarde & Restauration Intégrale</h3>
            <p className="text-xs text-slate-500">
              Assure la conformité avec l'exigence fondamentale de zéro perte de données lors des mises à jour.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-5 rounded-xl border border-slate-200 bg-slate-50 text-center space-y-3">
              <Download className="w-8 h-8 text-emerald-700 mx-auto" />
              <div>
                <h4 className="font-bold text-slate-900 text-xs">Exporter une Sauvegarde JSON</h4>
                <p className="text-[11px] text-slate-500 mt-0.5">Téléchargez l'intégralité des biens, baux, locataires et paiements.</p>
              </div>
              <button
                type="button"
                onClick={onExportBackup}
                className="w-full py-2 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold text-xs cursor-pointer transition-colors"
              >
                Télécharger le fichier .json
              </button>
            </div>

            <div className="p-5 rounded-xl border border-slate-200 bg-slate-50 text-center space-y-3">
              <Upload className="w-8 h-8 text-blue-600 mx-auto" />
              <div>
                <h4 className="font-bold text-slate-900 text-xs">Restaurer depuis une Sauvegarde</h4>
                <p className="text-[11px] text-slate-500 mt-0.5">Restauration sécurisée avec contrôle d'intégrité de schéma.</p>
              </div>
              <label className="w-full inline-block py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-xs cursor-pointer transition-colors">
                Importer un fichier .json
                <input
                  type="file"
                  accept=".json"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        const content = event.target?.result as string;
                        if (content) onImportBackup(content);
                      };
                      reader.readAsText(file);
                    }
                  }}
                />
              </label>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500">Réinitialiser les données de démonstration du Niger :</span>
            <button
              type="button"
              onClick={onResetFactory}
              className="px-3 py-1.5 text-xs text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-lg font-medium transition-colors cursor-pointer"
            >
              Recharger les données démo Niamey
            </button>
          </div>
        </div>
      )}

      {/* Tab 5: Audit Logs */}
      {activeTab === 'logs' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
          <div className="p-5 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900">Journal d'Audit & Traçabilité des Opérations</h3>
            <p className="text-xs text-slate-500">Chaque création de bien, quittance ou validation de paiement est consignée.</p>
          </div>

          <div className="max-h-96 overflow-y-auto divide-y divide-slate-100 text-xs">
            {auditLogs.map(log => (
              <div key={log.id} className="p-3.5 flex items-start justify-between gap-4 hover:bg-slate-50">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-indigo-700">{log.action}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-600">{log.details}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono mt-0.5 block">
                    Organisation : {log.organizationId} · Par : {log.userEmail}
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono whitespace-nowrap">
                  {new Date(log.timestamp).toLocaleString('fr-FR')}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 6: Global organizations and properties */}
      {activeTab === 'organizations' && (
        <div className="space-y-5">
          <section className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Toutes les organisations</h3>
                <p className="text-xs text-slate-500">{organizations.length} organisation(s) enregistrée(s) sur la plateforme.</p>
              </div>
              <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                <input
                  value={newOrganizationName}
                  onChange={e => setNewOrganizationName(e.target.value)}
                  placeholder="Nom de la nouvelle organisation"
                  className="px-3 py-2 border border-slate-200 rounded-lg text-xs min-w-0"
                />
                <select
                  value={newOrganizationType}
                  onChange={e => setNewOrganizationType(e.target.value as 'individual' | 'agency')}
                  className="px-3 py-2 border border-slate-200 rounded-lg text-xs bg-white"
                >
                  <option value="agency">Agence</option>
                  <option value="individual">Propriétaire individuel</option>
                </select>
                <button
                  type="button"
                  disabled={creatingOrganization || !newOrganizationName.trim()}
                  onClick={async () => {
                    setCreatingOrganization(true);
                    try {
                      await onCreateOrganization(newOrganizationName, newOrganizationType);
                      setNewOrganizationName('');
                    } catch {
                      // L'erreur est déjà affichée par le gestionnaire de création dans App.
                    } finally {
                      setCreatingOrganization(false);
                    }
                  }}
                  className="px-3 py-2 rounded-lg bg-indigo-600 text-white text-xs font-semibold disabled:opacity-40"
                >
                  {creatingOrganization ? 'Création...' : '+ Créer'}
                </button>
              </div>
            </div>
            <div className="divide-y divide-slate-100">
              {organizations.map(org => (
                <div key={org.organizationId} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-slate-900">{org.organizationName || org.fullName}</p>
                    <p className="text-[11px] text-slate-500">{org.fullName} · {org.email}</p>
                    <p className="text-[10px] text-slate-400 font-mono">{org.organizationId}</p>
                    <span className={`inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-semibold ${org.isSuspended ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'}`}>
                      {org.isSuspended ? 'Suspendue' : 'Active'}
                    </span>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <input
                        value={organizationNameDrafts[org.organizationId] ?? org.organizationName ?? ''}
                        onChange={e => setOrganizationNameDrafts(prev => ({ ...prev, [org.organizationId]: e.target.value }))}
                        placeholder="Nom de l'organisation"
                        className="px-2 py-1.5 border border-slate-200 rounded-lg text-xs min-w-0"
                      />
                      <button
                        type="button"
                        disabled={savingOrganizationId === org.organizationId || !(organizationNameDrafts[org.organizationId] ?? org.organizationName ?? '').trim()}
                        onClick={async () => {
                          setSavingOrganizationId(org.organizationId);
                          try {
                            await onRenameOrganization(org.organizationId, organizationNameDrafts[org.organizationId] ?? org.organizationName ?? '');
                          } finally {
                            setSavingOrganizationId(null);
                          }
                        }}
                        className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold disabled:opacity-40"
                      >
                        Renommer
                      </button>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => onCreatePropertyForOrganization(org.organizationId)}
                      className="px-3 py-2 rounded-lg bg-emerald-700 text-white text-xs font-semibold hover:bg-emerald-800"
                    >
                      + Ajouter un bien
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const nextSuspended = !org.isSuspended;
                        if (window.confirm(`${nextSuspended ? 'Suspendre' : 'Réactiver'} toute l'organisation ${org.organizationName || org.organizationId} ?`)) {
                          onToggleOrganizationSuspension(org.organizationId, nextSuspended);
                        }
                      }}
                      className={`px-3 py-2 rounded-lg text-xs font-semibold ${org.isSuspended ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}
                    >
                      {org.isSuspended ? 'Réactiver' : 'Suspendre'}
                    </button>
                  </div>
                </div>
              ))}
              {organizations.length === 0 && <p className="p-5 text-xs text-slate-500">Aucune organisation récupérée. Vérifie les profils utilisateurs et les règles Firestore.</p>}
            </div>
          </section>

          <section className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
            <div className="p-5 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900">Tous les biens de la plateforme</h3>
              <p className="text-xs text-slate-500">{properties.length} bien(s), toutes organisations confondues.</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500">
                  <tr>
                    <th className="p-3">Bien</th>
                    <th className="p-3">Organisation</th>
                    <th className="p-3">Ville</th>
                    <th className="p-3">Loyer</th>
                    <th className="p-3">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {properties.map(property => {
                    const org = organizations.find(item => item.organizationId === property.organizationId);
                    return (
                      <tr key={property.id}>
                        <td className="p-3">
                          <p className="font-semibold text-slate-800">{property.title}</p>
                          <p className="text-[10px] text-slate-400">{property.type} · {property.address}</p>
                        </td>
                        <td className="p-3 text-slate-600">{org?.organizationName || org?.fullName || property.organizationId}</td>
                        <td className="p-3 text-slate-600">{property.city}</td>
                        <td className="p-3 font-mono">{Number(property.monthlyRent || 0).toLocaleString('fr-FR')} FCFA</td>
                        <td className="p-3">
                          <div className="flex gap-2">
                            <button type="button" onClick={() => onEditGlobalProperty(property)} className="text-indigo-600 font-semibold hover:underline">Modifier</button>
                            <button type="button" onClick={() => {
                              if (window.confirm(`Supprimer définitivement « ${property.title} » ?`)) onDeleteGlobalProperty(property.id);
                            }} className="text-rose-600 font-semibold hover:underline">Supprimer</button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {properties.length === 0 && (
                    <tr><td colSpan={5} className="p-5 text-center text-slate-500">Aucun bien enregistré.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      )}
    </div>
  );
};
